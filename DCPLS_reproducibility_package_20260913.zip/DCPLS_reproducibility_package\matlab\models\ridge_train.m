function model = ridge_train(X,y,lambda)
p=size(X,2);
model.beta=(X'*X+lambda*eye(p))\(X'*y);
model.betas=model.beta;
model.A=1;
model.lambda=lambda;
end
