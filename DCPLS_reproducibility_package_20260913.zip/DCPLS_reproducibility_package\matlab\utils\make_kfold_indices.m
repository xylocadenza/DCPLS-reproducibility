function foldId = make_kfold_indices(n,K,seed)
K = min(max(2,K),n);
rng(seed,'twister');
perm = randperm(n);
foldId = zeros(n,1);
for i = 1:n
    foldId(perm(i)) = mod(i-1,K)+1;
end
end
