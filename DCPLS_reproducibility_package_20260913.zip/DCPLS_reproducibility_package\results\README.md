# Results

This folder contains lightweight result files used by the manuscript and supplement.

Included:

- `summary/`: 47-task screening summary and failures
- `47task_outputs/`: per-task selected hyperparameters, prediction outputs, and publication tables
- `synthetic_geometry/`: synthetic SFF-energy validation summaries
- `fixed_vs_reestimated/`: fixed versus component-wise re-estimated operator ablation

Excluded:

- raw spectra
- large generated `.mat` objects
- figure binaries unless needed for final supplementary release

