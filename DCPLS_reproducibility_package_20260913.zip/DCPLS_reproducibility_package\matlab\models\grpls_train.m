function model = grpls_train(X,y,A,k,alpha)
%GRPLS_TRAIN Graph-regularized PLS using a kNN Laplacian penalty.
% The score smoothness penalty is w' X' L X w.
[n,p]=size(X); A=min([A,p,n-1]);
E=X; f=y(:);
W=zeros(p,A); P=zeros(p,A); q=zeros(A,1); betas=nan(p,A); actualA=0;
for a=1:A
    c=E'*f;
    if norm(c)<1e-14, break; end
    if alpha==0
        wt=c;
    else
        Q=graph_penalty(E,k);
        wt=(eye(p)+alpha*Q)\c;
    end
    if norm(wt)<1e-14, break; end
    w=wt/norm(wt); t=E*w; den=t'*t;
    if den<1e-14, break; end
    pvec=E'*t/den; qa=f'*t/den;
    W(:,a)=w; P(:,a)=pvec; q(a)=qa; actualA=a;
    Wa=W(:,1:a); Pa=P(:,1:a); qv=q(1:a);
    betas(:,a)=Wa*((Pa'*Wa)\qv);
    E=E-t*pvec'; f=f-t*qa;
end
if actualA==0
    model.beta=zeros(p,1); model.betas=zeros(p,1); model.A=0;
else
    model.beta=betas(:,actualA); model.betas=betas(:,1:actualA); model.A=actualA;
end
model.W=W(:,1:actualA); model.P=P(:,1:actualA); model.q=q(1:actualA);
model.k=k; model.alpha=alpha; model.type='GRPLS';
end

function Q=graph_penalty(X,k)
n=size(X,1); p=size(X,2); k=min(k,n-1);
D2=max(sum(X.^2,2)+sum(X.^2,2)'-2*(X*X'),0);
D2(1:n+1:end)=inf;
W=zeros(n,n);
finiteD=D2(isfinite(D2));
if isempty(finiteD), Q=zeros(p,p); return; end
sigma2=median(finiteD); if sigma2<=eps, sigma2=1; end
for i=1:n
    [~,ord]=sort(D2(i,:),'ascend'); idx=ord(1:k);
    wij=exp(-D2(i,idx)/(2*sigma2)); W(i,idx)=wij;
end
W=max(W,W');
L=diag(sum(W,2))-W;
Q=X'*L*X;
Q=(Q+Q')/2;
s=trace(Q)/p; if isfinite(s)&&s>1e-14, Q=Q/s; end
end
