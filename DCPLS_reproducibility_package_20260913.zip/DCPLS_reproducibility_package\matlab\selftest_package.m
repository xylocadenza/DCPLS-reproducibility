function selftest_package()
%SELFTEST_PACKAGE Fast structural test for the seven-method package.
ROOT=fileparts(mfilename('fullpath')); addpath(genpath(ROOT));
rng(7);
n=48; p=18;
u=2*rand(n,2)-1;
X=[u, u(:,1).^2, u(:,1).*u(:,2), u(:,2).^2, randn(n,p-5)*0.15];
X=X+0.02*randn(size(X));
y=1.2*u(:,1)-0.7*u(:,2)+0.08*randn(n,1);

cfg=default_dcpls_config();
cfg.nRepeats=2; cfg.testFraction=0.25; cfg.innerFolds=3;
cfg.AGrid=1:3; cfg.dGrid=2; cfg.kGrid=12; cfg.lambdaGrid=[0 0.1 1];
cfg.ridgeGrid=[1e-4 1e-2 1]; cfg.krrLambdaGrid=[1e-4 1e-2]; cfg.rbfGammaGrid=[0.1 1];
cfg.localKGrid=[12 18]; cfg.graphKGrid=[5 8]; cfg.graphAlphaGrid=[0 0.1 1];
cfg.nBootstrapCI=100; cfg.figureVisible='off';
cfg.outputDir=fullfile(ROOT,'results','SELFTEST');
if exist(cfg.outputDir,'dir'), rmdir(cfg.outputDir,'s'); end
R=run_dcpls_paper_experiment(X,y,'SELFTEST',cfg);
assert(height(R.summary)==numel(cfg.methods),'Not all methods reached summary output.');
for m=1:numel(cfg.methods)
    name=['scatter_' regexprep(cfg.methods{m},'[^A-Za-z0-9]','_') '.png'];
    assert(isfile(fullfile(cfg.outputDir,'figures',name)),['Missing ' name]);
end
assert(isfile(fullfile(cfg.outputDir,'figures','scatter_3x3_ALL_methods.png')),'Missing combined scatter plot.');
fprintf('\nAll package self-tests completed.\n');
end
