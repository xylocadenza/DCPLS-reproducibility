function model = pls_nipals_train(X,y,A)
[n,p] = size(X);
A = min([A,p,n-1]);
E = X; f = y(:);
W = zeros(p,A); P = zeros(p,A); q = zeros(A,1); betas = nan(p,A);
actualA = 0;
for a = 1:A
    c = E'*f;
    if norm(c) < 1e-14, break; end
    w = c/norm(c);
    t = E*w;
    den = t'*t;
    if den < 1e-14, break; end
    pvec = E'*t/den;
    qa = f'*t/den;
    W(:,a)=w; P(:,a)=pvec; q(a)=qa; actualA=a;
    Wa=W(:,1:a); Pa=P(:,1:a); qaVec=q(1:a);
    betas(:,a)=Wa*((Pa'*Wa)\qaVec);
    E=E-t*pvec';
    f=f-t*qa;
end
if actualA==0
    model.beta=zeros(p,1); model.betas=zeros(p,1); model.A=0;
else
    model.beta=betas(:,actualA); model.betas=betas(:,1:actualA); model.A=actualA;
end
model.W=W(:,1:actualA); model.P=P(:,1:actualA); model.q=q(1:actualA);
end
