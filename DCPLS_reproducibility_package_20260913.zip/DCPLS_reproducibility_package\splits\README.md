# Splits

This folder should contain calibration/test indices for fixed splits.

Current package status:

- For external calibration/test-set datasets, record original split files in the metadata table.
- For Kennard-Stone or random splits, use the deterministic routines in `scripts/` and `matlab/utils/`.
- If final publication requires exact index files, add CSV files here using names such as:
  - `NITSingleSeed_calibration_indices.csv`
  - `NITSingleSeed_test_indices.csv`
  - `Soil_fertility_y1552_calibration_indices.csv`
  - `Soil_fertility_y1552_test_indices.csv`

Do not include raw third-party spectra in this folder.

