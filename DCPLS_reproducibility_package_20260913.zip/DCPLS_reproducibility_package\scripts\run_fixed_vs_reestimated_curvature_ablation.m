%% run_fixed_vs_reestimated_curvature_ablation.m
% Complexity-matched ablation of fixed and component-wise SFF operators.

clc;
close all;

ROOT = fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
addpath('E:\MATLAB\specdataset');
addpath('E:\MATLAB\libPLS_1.95');

dataDir = 'E:\MATLAB\specdataset';
resultRoot = fullfile(ROOT,'results','MANIFEST_SELECTED_FULL');
outRoot = fullfile(ROOT,'results','FIXED_VS_REESTIMATED_ABLATION');
if ~exist(outRoot,'dir'), mkdir(outRoot); end

cfg = default_dcpls_config();
cfg.saveFigures = false;
cfg.figureVisible = 'off';
Agrid = 1:10;
specs = local_specs(dataDir);
rows = cell(0,14);
summaryRows = cell(0,15);

% Exact implementation check: lambda=0 must equal ordinary NIPALS PLS.
rng(20260912,'twister');
Xt = randn(45,18); yt = randn(45,1);
p0 = pls_nipals_train(Xt,yt,8);
d0 = dcpls_fixed_train(Xt,yt,8,2,15,0,cfg);
d1 = dcpls_train(Xt,yt,8,2,15,0,cfg);
tol = 1e-10;
assert(max(abs(p0.betas(:)-d0.betas(:))) < tol,'Fixed lambda=0 check failed.');
assert(max(abs(p0.betas(:)-d1.betas(:))) < tol,'Re-estimated lambda=0 check failed.');

for si = 1:numel(specs)
    spec = specs(si);
    fprintf('\n=== %s ===\n',spec.name);
    [Xtrain,ytrain,Xtest,ytest] = local_load(spec);
    [Xtrain,Xtest] = local_limit_predictors(Xtrain,Xtest,300);
    [Xtr,Xte] = preprocess_fit_apply(Xtrain,Xtest,cfg.preprocess);
    yMean = mean(ytrain);
    yc = ytrain-yMean;
    hp = readtable(fullfile(resultRoot,spec.name,'selected_hyperparameters.csv'), ...
        'TextType','string');
    ix = find(strcmpi(hp.Method,'DC-PLS') | strcmpi(hp.Method,'DCPLS'),1);
    if isempty(ix), error('Missing DC-PLS settings for %s.',spec.name); end
    d = hp.d(ix); k = hp.k(ix); lambda = hp.lambda(ix);
    Amax = min([max(Agrid),size(Xtr,1)-1,size(Xtr,2)]);

    tic; pls = pls_nipals_train(Xtr,yc,Amax); timePLS = toc;
    tic; fixed = dcpls_fixed_train(Xtr,yc,Amax,d,k,lambda,cfg); timeFixed = toc;
    tic; reest = dcpls_train(Xtr,yc,Amax,d,k,lambda,cfg); timeReest = toc;
    Q0 = fixed.Qfixed;

    for A = Agrid(Agrid<=min([pls.A,fixed.A,reest.A]))
        vals = struct();
        vals.PLS = local_metrics(pls.betas(:,A),Xtr,Xte,ytrain,ytest,yMean);
        vals.Fixed = local_metrics(fixed.betas(:,A),Xtr,Xte,ytrain,ytest,yMean);
        vals.Reestimated = local_metrics(reest.betas(:,A),Xtr,Xte,ytrain,ytest,yMean);
        models = {pls,fixed,reest}; names = {'PLS','Fixed','Reestimated'};
        times = [timePLS,timeFixed,timeReest];
        for mi = 1:3
            w = models{mi}.W(:,A); w = w/max(norm(w),eps);
            initialExposure = real(w'*Q0*w);
            currentExposure = initialExposure;
            if mi==3 && numel(reest.Q)>=A && ~isempty(reest.Q{A})
                currentExposure = real(w'*reest.Q{A}*w);
            end
            m = vals.(names{mi});
            rows(end+1,:) = {spec.name,names{mi},A,d,k,lambda,m.RMSEC,m.R2C, ...
                m.RMSEP,m.R2P,initialExposure,currentExposure,times(mi), ...
                100*(vals.PLS.RMSEP-m.RMSEP)/vals.PLS.RMSEP}; %#ok<SAGROW>
        end
    end

    Ttmp = cell2table(rows,'VariableNames',local_var_names());
    D = Ttmp(strcmp(Ttmp.Dataset,spec.name),:);
    [~,ip] = min(D.RMSEP(strcmp(D.Mode,'PLS')));
    [~,ifx] = min(D.RMSEP(strcmp(D.Mode,'Fixed')));
    [~,ire] = min(D.RMSEP(strcmp(D.Mode,'Reestimated')));
    P = D(strcmp(D.Mode,'PLS'),:); F = D(strcmp(D.Mode,'Fixed'),:);
    R = D(strcmp(D.Mode,'Reestimated'),:);
    summaryRows(end+1,:) = {spec.name,d,k,lambda,P.A(ip),P.RMSEP(ip), ...
        F.A(ifx),F.RMSEP(ifx),R.A(ire),R.RMSEP(ire), ...
        100*(P.RMSEP(ip)-F.RMSEP(ifx))/P.RMSEP(ip), ...
        100*(P.RMSEP(ip)-R.RMSEP(ire))/P.RMSEP(ip),timePLS,timeFixed,timeReest}; %#ok<SAGROW>
end

T = cell2table(rows,'VariableNames',local_var_names());
S = cell2table(summaryRows,'VariableNames',{'Dataset','d','k','lambda', ...
    'PLS_bestA','PLS_bestRMSEP','Fixed_bestA','Fixed_bestRMSEP', ...
    'Reestimated_bestA','Reestimated_bestRMSEP','Fixed_gain_pct', ...
    'Reestimated_gain_pct','PLS_time_s','Fixed_time_s','Reestimated_time_s'});
writetable(T,fullfile(outRoot,'component_matched_results.csv'));
writetable(S,fullfile(outRoot,'ablation_summary.csv'));
commonRows = cell(0,10);
for si = 1:numel(specs)
    hp = readtable(fullfile(resultRoot,specs(si).name,'selected_hyperparameters.csv'), ...
        'TextType','string');
    ix = find(strcmpi(hp.Method,'DC-PLS') | strcmpi(hp.Method,'DCPLS'),1);
    commonA = hp.A(ix);
    D = T(strcmp(T.Dataset,specs(si).name) & T.A==commonA,:);
    p = D(strcmp(D.Mode,'PLS'),:); f = D(strcmp(D.Mode,'Fixed'),:);
    r = D(strcmp(D.Mode,'Reestimated'),:);
    winner = "Reestimated"; if f.RMSEP < r.RMSEP, winner = "Fixed"; end
    commonRows(end+1,:) = {specs(si).name,commonA,p.RMSEP,f.RMSEP,r.RMSEP, ...
        100*(p.RMSEP-f.RMSEP)/p.RMSEP,100*(p.RMSEP-r.RMSEP)/p.RMSEP, ...
        f.InitialQExposure,r.InitialQExposure,char(winner)}; %#ok<SAGROW>
end
C = cell2table(commonRows,'VariableNames',{'Dataset','CommonA','PLS_RMSEP', ...
    'Fixed_RMSEP','Reestimated_RMSEP','Fixed_gain_pct','Reestimated_gain_pct', ...
    'Fixed_initialQ_exposure','Reestimated_initialQ_exposure','Better_DCPLS_mode'});
writetable(C,fullfile(outRoot,'common_component_summary.csv'));
disp(S);
disp(C);

function names = local_var_names()
names = {'Dataset','Mode','A','d','k','lambda','RMSEC','R2_train','RMSEP', ...
    'R2_test','InitialQExposure','CurrentQExposure','FitTime_s','GainVsPLS_pct'};
end

function m = local_metrics(beta,Xtr,Xte,ytr,yte,yMean)
m = regression_metrics(ytr,yMean+Xtr*beta,yte,yMean+Xte*beta);
end

function specs = local_specs(dataDir)
specs = struct('name',{},'mode',{},'file',{},'xCols',{},'yCol',{}, ...
    'xVar',{},'yVar',{},'xVar2',{},'yVar2',{});
specs(end+1) = struct('name','NITSingleSeed','mode','mat_pair', ...
    'file',fullfile(dataDir,'NITSingleSeed.MAT'),'xCols',[],'yCol',1, ...
    'xVar','Calibration_X','yVar','Calibration_Y','xVar2','Validation_X','yVar2','Validation_Y');
specs(end+1) = struct('name','Soil_fertility_y1552','mode','matrix', ...
    'file',fullfile(dataDir,'Soil fertility.xlsx'),'xCols',1:1551,'yCol',1552, ...
    'xVar','','yVar','','xVar2','','yVar2','');
specs(end+1) = struct('name','HunanwetProtein','mode','matrix', ...
    'file',fullfile(dataDir,'HunanwetProtein.xlsx'),'xCols',3:143,'yCol',2, ...
    'xVar','','yVar','','xVar2','','yVar2','');
specs(end+1) = struct('name','NIRgrass_y1','mode','mat_ks', ...
    'file',fullfile(dataDir,'NIRgrass.mat'),'xCols',[],'yCol',1, ...
    'xVar','specgrass','yVar','propgrass','xVar2','','yVar2','');
specs(end+1) = struct('name','Faba_bean_Protein','mode','matrix', ...
    'file',fullfile(dataDir,'Faba_bean.csv'),'xCols',15,'yCol',6, ...
    'xVar','','yVar','','xVar2','','yVar2','');
end

function [Xtr,ytr,Xte,yte] = local_load(s)
switch s.mode
    case 'mat_pair'
        D=load(s.file); Xtr=D.(s.xVar); Ytr=D.(s.yVar); ytr=Ytr(:,s.yCol);
        Xte=D.(s.xVar2); Yte=D.(s.yVar2); yte=Yte(:,s.yCol);
    case 'mat_ks'
        D=load(s.file); X=D.(s.xVar); Y=D.(s.yVar); y=Y(:,s.yCol);
        [X,y]=local_clean(X,y); [Xtr,ytr,Xte,yte]=local_ks(X,y);
    case 'matrix'
        M=readmatrix(s.file);
        if isscalar(s.xCols), cols=s.xCols:size(M,2);
        else, cols=s.xCols(s.xCols<=size(M,2)); end
        X=M(2:end,cols); y=M(2:end,s.yCol); [X,y]=local_clean(X,y);
        [Xtr,ytr,Xte,yte]=local_ks(X,y);
end
[Xtr,ytr]=local_clean(Xtr,ytr); [Xte,yte]=local_clean(Xte,yte);
end

function [X,y]=local_clean(X,y)
X=double(X); y=double(y(:)); good=all(isfinite(X),2)&isfinite(y);
X=X(good,:); y=y(good);
end

function [Xtr,ytr,Xte,yte]=local_ks(X,y)
ord=ks(X); ntr=max(2,min(size(X,1)-1,floor(0.8*size(X,1))));
tr=ord(1:ntr); te=ord(ntr+1:end);
Xtr=X(tr,:); ytr=y(tr); Xte=X(te,:); yte=y(te);
end

function [Xtr,Xte]=local_limit_predictors(Xtr,Xte,maxP)
if size(Xtr,2)>maxP
    idx=unique(round(linspace(1,size(Xtr,2),maxP)));
    Xtr=Xtr(:,idx); Xte=Xte(:,idx);
end
end
