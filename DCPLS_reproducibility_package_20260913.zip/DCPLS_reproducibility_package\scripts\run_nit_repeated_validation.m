clear; clc;

addpath(genpath(pwd));

cfg = default_dcpls_config();
cfg.seed = 20260912;
cfg.methods = {'PLS','DC-PLS'};
cfg.nRepeats = 50;
cfg.testFraction = 0.20;
cfg.confLevel = 0.95;
cfg.nBootstrapCI = 5000;

fixedTune.PLS = struct('A',8,'d',NaN,'k',NaN,'lambda',NaN,'ridgeLambda',NaN, ...
    'localK',NaN,'graphK',NaN,'graphAlpha',NaN,'rbfGamma',NaN,'krrLambda',NaN, ...
    'sparseTau',NaN,'kplsGamma',NaN,'RMSECV',NaN);
fixedTune.DCPLS = struct('A',8,'d',2,'k',25,'lambda',10,'ridgeLambda',NaN, ...
    'localK',NaN,'graphK',NaN,'graphAlpha',NaN,'rbfGamma',NaN,'krrLambda',NaN, ...
    'sparseTau',NaN,'kplsGamma',NaN,'RMSECV',NaN);

outDir = fullfile(pwd,'results','NIT_REPEATED_50');
if ~exist(outDir,'dir'), mkdir(outDir); end

dataFile = fullfile('E:\MATLAB\specdataset','NITSingleSeed.MAT');
S = load(dataFile);
X = [double(S.Calibration_X); double(S.Validation_X)];
y = [local_y_column(S.Calibration_Y,1); local_y_column(S.Validation_Y,1)];
[X,y] = local_clean_rows(X,y);

maxPredictors = 300;
if size(X,2) > maxPredictors
    idx = unique(round(linspace(1,size(X,2),maxPredictors)));
    X = X(:,idx);
end

repeatRows = {};
hyperRows = {};
predRows = {};
fprintf('NIT repeated validation: n=%d, p=%d, repeats=%d\n',size(X,1),size(X,2),cfg.nRepeats);

for r = 1:cfg.nRepeats
    rng(cfg.seed + r,'twister');
    [idxCal,idxTest] = random_holdout_indices(size(X,1),cfg.testFraction);
    XcalRaw = X(idxCal,:); ycalRaw = y(idxCal);
    XtestRaw = X(idxTest,:); ytestRaw = y(idxTest);

    for mi = 1:numel(cfg.methods)
        method = cfg.methods{mi};
        fprintf('Repeat %02d/%02d: %s\n',r,cfg.nRepeats,method);
        if strcmp(method,'PLS')
            tune = fixedTune.PLS;
        else
            tune = fixedTune.DCPLS;
        end
        [Xcal,Xtest,~] = preprocess_fit_apply(XcalRaw,XtestRaw,cfg.preprocess);
        muY = mean(ycalRaw);
        ycal = ycalRaw - muY;
        ytest = ytestRaw - muY;
        Amax = 8;
        [model,~] = fit_method_with_curve(Xcal,ycal,method,tune,cfg,Amax);
        yhatCal = predict_model(model,Xcal) + muY;
        yhatTest = predict_model(model,Xtest) + muY;
        met = regression_metrics(ycalRaw,yhatCal,ytestRaw,yhatTest);

        repeatRows(end+1,:) = {r,method,met.RMSEC,met.R2C,met.RMSEP,met.R2P}; %#ok<SAGROW>
        hyperRows(end+1,:) = {r,method,tune.A,tune.d,tune.k,tune.lambda,tune.ridgeLambda,tune.graphK,tune.graphAlpha,tune.RMSECV}; %#ok<SAGROW>
        for ii = 1:numel(ytestRaw)
            predRows(end+1,:) = {r,method,ii,ytestRaw(ii),yhatTest(ii)}; %#ok<SAGROW>
        end
    end
end

repeatTable = cell2table(repeatRows,'VariableNames',{'Repeat','Method','RMSEC','R2C','RMSEP','R2P'});
hyperTable = cell2table(hyperRows,'VariableNames',{'Repeat','Method','A','d','k','lambda','ridgeLambda','graphK','graphAlpha','RMSECV'});
predTable = cell2table(predRows,'VariableNames',{'Repeat','Method','TestIndex','Reference','Predicted'});

summaryTable = summarize_performance_with_ci(repeatTable,cfg);
testTable = local_paired_tests(repeatTable,'PLS');

writetable(repeatTable,fullfile(outDir,'repeat_metrics.csv'));
writetable(hyperTable,fullfile(outDir,'selected_hyperparameters.csv'));
writetable(predTable,fullfile(outDir,'repeat_predictions.csv'));
writetable(summaryTable,fullfile(outDir,'summary_ci.csv'));
writetable(testTable,fullfile(outDir,'paired_t_tests_vs_pls.csv'));

save(fullfile(outDir,'nit_repeated_validation.mat'),'repeatTable','hyperTable','predTable','summaryTable','testTable','cfg');
disp(summaryTable);
disp(testTable);
fprintf('Saved repeated validation results to: %s\n',outDir);

function y = local_y_column(Y,yCol)
if isvector(Y)
    y = Y(:);
else
    y = Y(:,min(yCol,size(Y,2)));
end
end

function [X,y] = local_clean_rows(X,y)
X = double(X);
y = double(y(:));
good = all(isfinite(X),2) & isfinite(y);
X = X(good,:);
y = y(good);
end

function T = local_paired_tests(repeatTable,refMethod)
methods = unique(repeatTable.Method,'stable');
ref = repeatTable(strcmp(repeatTable.Method,refMethod),:);
rows = {};
for i = 1:numel(methods)
    method = methods{i};
    cur = repeatTable(strcmp(repeatTable.Method,method),:);
    [~,ia,ib] = intersect(ref.Repeat,cur.Repeat);
    dRMSEP = ref.RMSEP(ia) - cur.RMSEP(ib);
    dRMSEC = ref.RMSEC(ia) - cur.RMSEC(ib);
    dR2P = cur.R2P(ib) - ref.R2P(ia);
    dR2C = cur.R2C(ib) - ref.R2C(ia);
    if strcmp(method,refMethod)
        pRMSEP = NaN; pRMSEC = NaN; pR2P = NaN; pR2C = NaN;
    else
        [~,pRMSEP] = ttest(dRMSEP);
        [~,pRMSEC] = ttest(dRMSEC);
        [~,pR2P] = ttest(dR2P);
        [~,pR2C] = ttest(dR2C);
    end
    rows(end+1,:) = {method,mean(dRMSEP),pRMSEP,mean(dRMSEC),pRMSEC,mean(dR2P),pR2P,mean(dR2C),pR2C}; %#ok<AGROW>
end
T = cell2table(rows,'VariableNames',{'Method','MeanDeltaRMSEP_vsPLS','p_RMSEP','MeanDeltaRMSEC_vsPLS','p_RMSEC','MeanDeltaR2Test_vsPLS','p_R2Test','MeanDeltaR2Train_vsPLS','p_R2Train'});
end
