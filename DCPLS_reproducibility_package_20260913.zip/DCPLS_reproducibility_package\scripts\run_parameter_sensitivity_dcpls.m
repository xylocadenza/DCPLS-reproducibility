%% run_parameter_sensitivity_dcpls.m
% Parameter sensitivity and curvature-exposure/gain diagnostic figures.

clc;
close all;

ROOT = fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
addpath('E:\MATLAB\specdataset');
addpath('E:\MATLAB\libPLS_1.95');

if ~exist('dataDir','var'), dataDir = 'E:\MATLAB\specdataset'; end
if ~exist('fixedRoot','var'), fixedRoot = fullfile(ROOT,'results','SPEC_DATASETS'); end
if ~exist('repeatRoot','var'), repeatRoot = fullfile(ROOT,'results','FAST_REPEATED_SPLITS_ALL11'); end
if ~exist('outRoot','var'), outRoot = fullfile(ROOT,'results','PARAMETER_SENSITIVITY'); end
if ~exist('paperDir','var'), paperDir = 'F:\文档\Directional Curvature-Informed PLS'; end

if ~exist(outRoot,'dir'), mkdir(outRoot); end
figureDir = fullfile(paperDir,'figure');
if ~exist(figureDir,'dir'), mkdir(figureDir); end

cfg = default_dcpls_config();
cfg.figureVisible = 'off';
cfg.saveFigures = false;
cfg.exportPNG = false;
cfg.exportFIG = false;

lambdaGrid = [0 0.001 0.01 0.1 1 10];
kGrid = [10 15 20 25 30 40];
specs = local_representative_specs(dataDir);

sensRows = {};
exposureRows = {};

for si = 1:numel(specs)
    spec = specs(si);
    fprintf('\n=== Sensitivity: %s ===\n',spec.name);
    [Xtrain,ytrain,Xtest,ytest] = local_load_dataset(spec);
    [Xtr,Xte] = preprocess_fit_apply(Xtrain,Xtest,cfg.preprocess);
    yMean = mean(ytrain);
    ytr = ytrain - yMean;
    Amax = min(10,min(size(Xtr,2),size(Xtr,1)-1));

    hp = readtable(fullfile(fixedRoot,local_safe_name(spec.name),'selected_hyperparameters.csv'), ...
        'TextType','string');
    tunePLS = local_tune_from_table(hp,'PLS');
    tuneDC = local_tune_from_table(hp,'DC-PLS');

    [plsModel,~] = fit_method_with_curve(Xtr,ytr,'PLS',tunePLS,cfg,Amax);
    yhatPLS = yMean + predict_model(plsModel,Xte);
    metPLS = regression_metrics(ytrain,yMean + predict_model(plsModel,Xtr),ytest,yhatPLS);

    for li = 1:numel(lambdaGrid)
        tune = tuneDC;
        tune.lambda = lambdaGrid(li);
        [dcModel,~] = fit_method_with_curve(Xtr,ytr,'DC-PLS',tune,cfg,Amax);
        yhatDC = yMean + predict_model(dcModel,Xte);
        metDC = regression_metrics(ytrain,yMean + predict_model(dcModel,Xtr),ytest,yhatDC);
        exp = compute_curvature_exposure(plsModel,dcModel,dcModel.A);
        gain = 100*(metPLS.RMSEP-metDC.RMSEP)/metPLS.RMSEP;
        sensRows(end+1,:) = {spec.name,'lambda',lambdaGrid(li),tune.k, ...
            tune.d,metPLS.RMSEP,metDC.RMSEP,gain, ...
            exp.CurvatureExposure_PLS,exp.CurvatureExposure_DCPLS, ...
            exp.ExposureReduction_pct}; %#ok<SAGROW>
    end

    for ki = 1:numel(kGrid)
        tune = tuneDC;
        tune.k = kGrid(ki);
        [dcModel,~] = fit_method_with_curve(Xtr,ytr,'DC-PLS',tune,cfg,Amax);
        yhatDC = yMean + predict_model(dcModel,Xte);
        metDC = regression_metrics(ytrain,yMean + predict_model(dcModel,Xtr),ytest,yhatDC);
        exp = compute_curvature_exposure(plsModel,dcModel,dcModel.A);
        gain = 100*(metPLS.RMSEP-metDC.RMSEP)/metPLS.RMSEP;
        sensRows(end+1,:) = {spec.name,'k',kGrid(ki),tune.k, ...
            tune.d,metPLS.RMSEP,metDC.RMSEP,gain, ...
            exp.CurvatureExposure_PLS,exp.CurvatureExposure_DCPLS, ...
            exp.ExposureReduction_pct}; %#ok<SAGROW>
    end

    E = readtable(fullfile(fixedRoot,local_safe_name(spec.name),'curvature_exposure.csv'));
    S = readtable(fullfile(fixedRoot,local_safe_name(spec.name),'publication_table.csv'), ...
        'TextType','string');
    plsIx = strcmpi(S.Algorithm,'PLS');
    dcIx = strcmpi(S.Algorithm,'DC-PLS') | strcmpi(S.Algorithm,'DCPLS');
    fixedGain = 100*(S.RMSEP(plsIx)-S.RMSEP(dcIx))/S.RMSEP(plsIx);
    exposureRows(end+1,:) = {spec.name,'fixed', ...
        S.RMSEP(plsIx),S.RMSEP(dcIx),fixedGain, ...
        E.CurvatureExposure_PLS(1),E.CurvatureExposure_DCPLS(1), ...
        E.ExposureReduction_pct(1)}; %#ok<SAGROW>
end

sensTable = cell2table(sensRows,'VariableNames',{ ...
    'Dataset','Parameter','Value','k','d','PLS_RMSEP','DCPLS_RMSEP', ...
    'GainVsPLS_pct','CurvatureExposure_PLS','CurvatureExposure_DCPLS', ...
    'ExposureReduction_pct'});
writetable(sensTable,fullfile(outRoot,'parameter_sensitivity.csv'));

repeatSummary = readtable(fullfile(repeatRoot,'fast_repeated_split_summary.csv'), ...
    'TextType','string');
for si = 1:numel(specs)
    ix = strcmpi(repeatSummary.Dataset,specs(si).name);
    exposureRows(end+1,:) = {specs(si).name,'repeated', ...
        repeatSummary.PLS_RMSEP_mean(ix),repeatSummary.DCPLS_RMSEP_mean(ix), ...
        repeatSummary.Gain_mean_pct(ix),NaN,NaN, ...
        repeatSummary.ExposureReduction_mean_pct(ix)}; %#ok<SAGROW>
end

exposureTable = cell2table(exposureRows,'VariableNames',{ ...
    'Dataset','Source','PLS_RMSEP','DCPLS_RMSEP','GainVsPLS_pct', ...
    'CurvatureExposure_PLS','CurvatureExposure_DCPLS','ExposureReduction_pct'});
writetable(exposureTable,fullfile(outRoot,'exposure_vs_gain.csv'));

write_sensitivity_pgf(fullfile(figureDir,'parameter_sensitivity_pgf.tex'),sensTable);
write_exposure_gain_pgf(fullfile(figureDir,'curvature_exposure_vs_gain_pgf.tex'),exposureTable);

fprintf('\nWrote results to %s\n',outRoot);
fprintf('Wrote PGFPlots figures to %s\n',figureDir);

function tune = local_tune_from_table(T,method)
ix = find(strcmpi(T.Method,method) | (strcmpi(method,'DC-PLS') & strcmpi(T.Method,'DCPLS')),1);
if isempty(ix), error('Missing hyperparameters for %s.',method); end
names = {'A','d','k','lambda','ridgeLambda','localK','graphK','graphAlpha', ...
    'rbfGamma','krrLambda','sparseTau','kplsGamma','RMSECV'};
for i = 1:numel(names)
    if ismember(names{i},T.Properties.VariableNames)
        tune.(names{i}) = T.(names{i})(ix);
    else
        tune.(names{i}) = NaN;
    end
end
end

function specs = local_representative_specs(dataDir)
specs = struct('name',{},'mode',{},'file',{},'file2',{},'xRows',{}, ...
    'xCols',{},'yRows',{},'yCols',{},'ratio',{});
specs(end+1) = local_spec_matrix('HunanwetProtein','HunanwetProtein.xlsx',3,4,3,2,0.8);
specs(end+1) = local_spec_pair('Cucurbitaceae_Fruits','Cucurbitaceae_Fruits_train.xlsx','Cucurbitaceae_Fruits_test.xlsx',2,2,[]);
specs(end+1) = local_spec_matrix('Australian_Wheat_y8','Australian_Wheat.csv',2,9,2,8,0.8);
specs(end+1) = local_spec_matrix('Jin1','Jin1.xlsx',2,3,2,2,0.8);
specs(end+1) = local_spec_pair('HunandryOil','HunandryOil_train.xlsx','HunandryOil_test.xlsx',2,2:142,143);
for i = 1:numel(specs)
    specs(i).file = fullfile(dataDir,specs(i).file);
    if ~isempty(specs(i).file2), specs(i).file2 = fullfile(dataDir,specs(i).file2); end
end
end

function s = local_spec_matrix(name,file,xRowStart,xCols,yRowStart,yCols,ratio)
s = struct('name',name,'mode','matrix','file',file,'file2','', ...
    'xRows',xRowStart,'xCols',xCols,'yRows',yRowStart,'yCols',yCols,'ratio',ratio);
end

function s = local_spec_pair(name,trainFile,testFile,rowStart,xCols,yCol)
s = struct('name',name,'mode','pair','file',trainFile,'file2',testFile, ...
    'xRows',rowStart,'xCols',xCols,'yRows',rowStart,'yCols',yCol,'ratio',[]);
end

function [Xtrain,ytrain,Xtest,ytest] = local_load_dataset(spec)
switch spec.mode
    case 'matrix'
        I = readmatrix(spec.file);
        xCols = local_cols(spec.xCols,size(I,2));
        yCols = local_cols(spec.yCols,size(I,2));
        X = I(spec.xRows:size(I,1),xCols);
        y = I(spec.yRows:size(I,1),yCols(1));
        [X,y] = local_clean_rows(X,y);
        [Xtrain,ytrain,Xtest,ytest] = local_ks_split(X,y,spec.ratio);
    case 'pair'
        A = readmatrix(spec.file);
        B = readmatrix(spec.file2);
        yCol = spec.yCols;
        if isempty(yCol), yCol = min(size(A,2),size(B,2)); end
        xCols = intersect(local_cols(spec.xCols,size(A,2)),local_cols(spec.xCols,size(B,2)));
        xCols(xCols == yCol) = [];
        Xtrain = A(spec.xRows:size(A,1),xCols);
        ytrain = A(spec.xRows:size(A,1),yCol);
        Xtest = B(spec.xRows:size(B,1),xCols);
        ytest = B(spec.xRows:size(B,1),yCol);
        [Xtrain,ytrain] = local_clean_rows(Xtrain,ytrain);
        [Xtest,ytest] = local_clean_rows(Xtest,ytest);
end
end

function cols = local_cols(specCols,nCols)
if isscalar(specCols), cols = specCols:nCols; else, cols = specCols; end
cols = cols(cols >= 1 & cols <= nCols);
end

function [X,y] = local_clean_rows(X,y)
y = y(:);
good = all(isfinite(X),2) & isfinite(y);
X = X(good,:);
y = y(good);
end

function [Xtrain,ytrain,Xtest,ytest] = local_ks_split(X,y,ratio)
rank = ks(X);
nTrain = floor(ratio*size(X,1));
tr = rank(1:nTrain);
te = rank(nTrain+1:end);
Xtrain = X(tr,:);
ytrain = y(tr);
Xtest = X(te,:);
ytest = y(te);
end

function s = local_safe_name(s)
s = regexprep(s,'[^A-Za-z0-9_()-]','_');
end

function write_sensitivity_pgf(outFile,T)
fid = fopen(outFile,'w');
cleanup = onCleanup(@() fclose(fid));
datasets = unique(T.Dataset,'stable');
colors = {'blue','red','green!60!black','purple','orange'};
marks = {'o','square*','triangle*','diamond*','asterisk'};

fprintf(fid,'%% Auto-generated parameter sensitivity figure\n');
fprintf(fid,'\\begin{tikzpicture}\n');
fprintf(fid,'\\begin{groupplot}[group style={group size=2 by 1,horizontal sep=1.55cm},width=0.48\\linewidth,height=0.36\\linewidth,grid=major,grid style={dashed,gray!25},ylabel={RMSEP gain over PLS (\\%%)},tick label style={font=\\scriptsize},label style={font=\\scriptsize},legend style={font=\\tiny,at={(0.02,0.02)},anchor=south west},legend cell align={left}]\n');
fprintf(fid,'\\nextgroupplot[xmode=log,xlabel={$\\lambda$},title={Curvature weight}]\n');
for di = 1:numel(datasets)
    ix = strcmpi(T.Dataset,datasets{di}) & strcmpi(T.Parameter,'lambda');
    S = sortrows(T(ix,:),'Value');
    fprintf(fid,'\\addplot[color=%s,mark=%s,thick] coordinates {',colors{di},marks{di});
    for i = 1:height(S), fprintf(fid,'(%.8g,%.8g)',max(S.Value(i),1e-4),S.GainVsPLS_pct(i)); end
    fprintf(fid,'};\\addlegendentry{%s}\n',local_display_name(datasets{di}));
end
fprintf(fid,'\\nextgroupplot[xlabel={$k$},title={Neighborhood size}]\n');
for di = 1:numel(datasets)
    ix = strcmpi(T.Dataset,datasets{di}) & strcmpi(T.Parameter,'k');
    S = sortrows(T(ix,:),'Value');
    fprintf(fid,'\\addplot[color=%s,mark=%s,thick] coordinates {',colors{di},marks{di});
    for i = 1:height(S), fprintf(fid,'(%.8g,%.8g)',S.Value(i),S.GainVsPLS_pct(i)); end
    fprintf(fid,'};\n');
end
fprintf(fid,'\\end{groupplot}\n\\end{tikzpicture}\n');
end

function write_exposure_gain_pgf(outFile,T)
fid = fopen(outFile,'w');
cleanup = onCleanup(@() fclose(fid));
S = T(strcmpi(T.Source,'repeated'),:);
fprintf(fid,'%% Auto-generated curvature exposure versus gain figure\n');
fprintf(fid,'\\begin{tikzpicture}\n');
fprintf(fid,'\\begin{axis}[width=0.78\\linewidth,height=0.50\\linewidth,xlabel={Curvature exposure reduction (\\%%)},ylabel={RMSEP gain over PLS (\\%%)},grid=major,grid style={dashed,gray!25},tick label style={font=\\scriptsize},label style={font=\\scriptsize},xmin=0,xmax=100]\n');
fprintf(fid,'\\addplot[only marks,mark=*,mark size=2.3pt,blue!70!black] coordinates {');
for i = 1:height(S)
    fprintf(fid,'(%.8g,%.8g)',S.ExposureReduction_pct(i),S.GainVsPLS_pct(i));
end
fprintf(fid,'};\n');
for i = 1:height(S)
    fprintf(fid,'\\node[font=\\tiny,anchor=south west] at (axis cs:%.8g,%.8g) {%s};\n', ...
        S.ExposureReduction_pct(i),S.GainVsPLS_pct(i),local_display_name(S.Dataset{i}));
end
fprintf(fid,'\\addplot[black,dashed,domain=0:100,samples=2] {0};\n');
fprintf(fid,'\\end{axis}\n\\end{tikzpicture}\n');
end

function name = local_display_name(id)
switch id
    case 'HunanwetProtein', name = 'Hunan wet protein';
    case 'Cucurbitaceae_Fruits', name = 'Cucurbitaceae';
    case 'Australian_Wheat_y8', name = 'Australian wheat';
    case 'HunandryOil', name = 'Hunan dry oil';
    otherwise, name = strrep(id,'_','\_');
end
end
