function cfg = default_dcpls_config()
%DEFAULT_DCPLS_CONFIG Settings for the fixed-split DC-PLS paper package.

cfg.seed = 20260903;
cfg.innerFolds = 5;

cfg.methods = {'PLS','PCR','Ridge','KRR-RBF','LocalPLS', ...
               'SPLS','KPLS-RBF','GRPLS','DC-PLS'};

cfg.AGrid = 1:10;

% DC-PLS
cfg.dGrid = [2 3];
cfg.kGrid = [15 20 25 30];
cfg.lambdaGrid = [0 0.01 0.1 1 10];
cfg.responseCurvatureEps = 0.05;
cfg.responseCurvatureWeightCap = 10;

% Ridge / KRR-RBF
cfg.ridgeGrid = logspace(-6,2,12);
cfg.krrLambdaGrid = logspace(-6,1,8);
cfg.rbfGammaGrid = [0.01 0.05 0.1 0.5 1 2 5];

% LocalPLS
cfg.localKGrid = [15 20 30 40];

% SPLS
cfg.sparseTauGrid = [0 0.1 0.25 0.5 0.75];

% KPLS-RBF
cfg.kplsGammaGrid = [0.01 0.05 0.1 0.5 1 2 5];

% GRPLS
cfg.graphKGrid = [5 10 15];
cfg.graphAlphaGrid = [0 0.01 0.1 1 10];

cfg.preprocess = 'center';

% Curvature estimator
cfg.kernel = 'tricube';
cfg.geomRidge = 1e-6;
cfg.geomLinearRidgeFactor = 0.1;
cfg.qNormalize = true;
cfg.minWeight = 1e-8;


% Figures
cfg.saveFigures = true;
cfg.figureVisible = 'on';
cfg.exportPNG = true;
cfg.exportFIG = true;
cfg.outputDir = fullfile(pwd,'results_DCPLS_fixed');

% One combined 3-by-3 scatter only
cfg.scatterCombined = true;
cfg.scatterIndividual = false;
cfg.scatterRows = 3;
cfg.scatterCols = 3;

cfg.componentCurveMethods = {'PLS','PCR','SPLS','KPLS-RBF','GRPLS','DC-PLS'};
end
