function key = method_key(method)
key = regexprep(upper(method),'[^A-Z0-9]','_');
if isempty(key) || ~isletter(key(1))
    key = ['M_' key];
end
end
