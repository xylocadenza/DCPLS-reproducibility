%% run_fast_repeated_split_dcpls_stats.m
% Fast repeated-split robustness test using fixed-split selected parameters.

clc;
close all;

ROOT = fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
addpath('E:\MATLAB\specdataset');
addpath('E:\MATLAB\libPLS_1.95');

if ~exist('dataDir','var'), dataDir = 'E:\MATLAB\specdataset'; end
if ~exist('fixedRoot','var'), fixedRoot = fullfile(ROOT,'results','SPEC_DATASETS'); end
if ~exist('outRoot','var'), outRoot = fullfile(ROOT,'results','FAST_REPEATED_SPLITS'); end
if ~exist('nRepeats','var'), nRepeats = 30; end
if ~exist('baseSeed','var'), baseSeed = 20260910; end
if ~exist('includeAllDatasets','var'), includeAllDatasets = false; end

if ~exist(outRoot,'dir'), mkdir(outRoot); end

cfg = default_dcpls_config();
cfg.figureVisible = 'off';
cfg.saveFigures = false;
cfg.exportPNG = false;
cfg.exportFIG = false;

if includeAllDatasets
    specs = local_all_specs(dataDir);
else
    specs = local_representative_specs(dataDir);
end
specs = local_existing_specs(specs);
allRows = {};
summaryRows = {};

fprintf('Fast repeated split DC-PLS robustness test\n');
fprintf('Repeats per dataset: %d\n',nRepeats);
fprintf('Output root: %s\n\n',outRoot);

for si = 1:numel(specs)
    spec = specs(si);
    fprintf('\n=== %s ===\n',spec.name);
    [X,y] = local_load_full_dataset(spec);
    [X,y] = local_clean_rows(X,y);

    hp = readtable(fullfile(fixedRoot,local_safe_name(spec.name),'selected_hyperparameters.csv'), ...
        'TextType','string');
    tunePLS = local_tune_from_table(hp,'PLS');
    tuneDC = local_tune_from_table(hp,'DC-PLS');
    tuneNoCurv = tuneDC;
    tuneNoCurv.lambda = 0;

    rmsepPLS = nan(nRepeats,1);
    rmsepDC = nan(nRepeats,1);
    rmsepNoCurv = nan(nRepeats,1);
    r2pPLS = nan(nRepeats,1);
    r2pDC = nan(nRepeats,1);
    gain = nan(nRepeats,1);
    exposurePLS = nan(nRepeats,1);
    exposureDC = nan(nRepeats,1);
    exposureReduction = nan(nRepeats,1);

    for r = 1:nRepeats
        rng(baseSeed + 1000*si + r,'twister');
        [tr,te] = local_random_split(size(X,1),0.8);

        Xtrain = X(tr,:);
        ytrain = y(tr);
        Xtest = X(te,:);
        ytest = y(te);

        [Xtr,Xte] = preprocess_fit_apply(Xtrain,Xtest,cfg.preprocess);
        yMean = mean(ytrain);
        ytr = ytrain - yMean;
        Amax = min(10,min(size(Xtr,2),size(Xtr,1)-1));

        [plsModel,~] = fit_method_with_curve(Xtr,ytr,'PLS',tunePLS,cfg,Amax);
        [dcModel,~] = fit_method_with_curve(Xtr,ytr,'DC-PLS',tuneDC,cfg,Amax);
        [noCurvModel,~] = fit_method_with_curve(Xtr,ytr,'DC-PLS',tuneNoCurv,cfg,Amax);

        yhatPLS = yMean + predict_model(plsModel,Xte);
        yhatDC = yMean + predict_model(dcModel,Xte);
        yhatNoCurv = yMean + predict_model(noCurvModel,Xte);

        metPLS = regression_metrics(ytrain,yMean + predict_model(plsModel,Xtr),ytest,yhatPLS);
        metDC = regression_metrics(ytrain,yMean + predict_model(dcModel,Xtr),ytest,yhatDC);
        metNoCurv = regression_metrics(ytrain,yMean + predict_model(noCurvModel,Xtr),ytest,yhatNoCurv);

        rmsepPLS(r) = metPLS.RMSEP;
        rmsepDC(r) = metDC.RMSEP;
        rmsepNoCurv(r) = metNoCurv.RMSEP;
        r2pPLS(r) = metPLS.R2P;
        r2pDC(r) = metDC.R2P;
        gain(r) = 100*(rmsepPLS(r)-rmsepDC(r))/rmsepPLS(r);

        exp = local_curvature_exposure_sameQ(plsModel,dcModel,dcModel.A);
        exposurePLS(r) = exp(1);
        exposureDC(r) = exp(2);
        exposureReduction(r) = exp(3);

        allRows(end+1,:) = {spec.name,r,rmsepPLS(r),rmsepDC(r), ...
            rmsepNoCurv(r),r2pPLS(r),r2pDC(r),gain(r), ...
            exposurePLS(r),exposureDC(r),exposureReduction(r), ...
            tunePLS.A,tuneDC.A,tuneDC.d,tuneDC.k,tuneDC.lambda}; %#ok<SAGROW>

        fprintf('%02d: PLS %.6g, DC %.6g, no-curv %.6g, gain %.2f%%\n', ...
            r,rmsepPLS(r),rmsepDC(r),rmsepNoCurv(r),gain(r));
    end

    valid = isfinite(rmsepPLS) & isfinite(rmsepDC);
    [pSign,wins,losses,ties] = local_two_sided_sign_p(rmsepPLS(valid)-rmsepDC(valid));
    gainCI = local_mean_ci(gain(valid));
    expCI = local_mean_ci(exposureReduction(valid));

    summaryRows(end+1,:) = {spec.name,sum(valid), ...
        mean(rmsepPLS(valid)),std(rmsepPLS(valid)), ...
        mean(rmsepDC(valid)),std(rmsepDC(valid)), ...
        mean(rmsepNoCurv(valid)),std(rmsepNoCurv(valid)), ...
        mean(gain(valid)),std(gain(valid)),gainCI(1),gainCI(2), ...
        wins,losses,ties,pSign, ...
        mean(exposureReduction(valid),'omitnan'),expCI(1),expCI(2), ...
        tunePLS.A,tuneDC.A,tuneDC.d,tuneDC.k,tuneDC.lambda}; %#ok<SAGROW>
end

runTable = cell2table(allRows,'VariableNames',{ ...
    'Dataset','Repeat','PLS_RMSEP','DCPLS_RMSEP','DCPLS_no_curvature_RMSEP', ...
    'PLS_R2P','DCPLS_R2P','GainVsPLS_pct', ...
    'CurvatureExposure_PLS','CurvatureExposure_DCPLS','ExposureReduction_pct', ...
    'PLS_A','DCPLS_A','DCPLS_d','DCPLS_k','DCPLS_lambda'});

summaryTable = cell2table(summaryRows,'VariableNames',{ ...
    'Dataset','N','PLS_RMSEP_mean','PLS_RMSEP_sd', ...
    'DCPLS_RMSEP_mean','DCPLS_RMSEP_sd', ...
    'DCPLS_no_curvature_RMSEP_mean','DCPLS_no_curvature_RMSEP_sd', ...
    'Gain_mean_pct','Gain_sd_pct','Gain_CI95_low_pct','Gain_CI95_high_pct', ...
    'Wins','Losses','Ties','SignTest_p', ...
    'ExposureReduction_mean_pct','ExposureReduction_CI95_low_pct', ...
    'ExposureReduction_CI95_high_pct','PLS_A','DCPLS_A','DCPLS_d', ...
    'DCPLS_k','DCPLS_lambda'});

writetable(runTable,fullfile(outRoot,'fast_repeated_split_runs.csv'));
writetable(summaryTable,fullfile(outRoot,'fast_repeated_split_summary.csv'));

disp(summaryTable);

function tune = local_tune_from_table(T,method)
ix = find(strcmpi(T.Method,method) | (strcmpi(method,'DC-PLS') & strcmpi(T.Method,'DCPLS')),1);
if isempty(ix), error('Missing hyperparameters for %s.',method); end
names = {'A','d','k','lambda','ridgeLambda','localK','graphK','graphAlpha', ...
    'rbfGamma','krrLambda','sparseTau','kplsGamma','RMSECV'};
for i = 1:numel(names)
    if ismember(names{i},T.Properties.VariableNames)
        tune.(names{i}) = T.(names{i})(ix);
    else
        tune.(names{i}) = NaN;
    end
end
end

function specs = local_representative_specs(dataDir)
specs = struct('name',{},'file',{},'file2',{},'xRows',{},'xCols',{}, ...
    'yRows',{},'yCols',{});
specs(end+1) = local_spec('HunanwetProtein','HunanwetProtein.xlsx','',3,4,3,2);
specs(end+1) = local_spec('Cucurbitaceae_Fruits','Cucurbitaceae_Fruits_train.xlsx','Cucurbitaceae_Fruits_test.xlsx',2,2,2,[]);
specs(end+1) = local_spec('Australian_Wheat_y8','Australian_Wheat.csv','',2,9,2,8);
specs(end+1) = local_spec('Jin1','Jin1.xlsx','',2,3,2,2);
specs(end+1) = local_spec('HunandryOil','HunandryOil_train.xlsx','HunandryOil_test.xlsx',2,2:142,2,143);
for i = 1:numel(specs)
    specs(i).file = fullfile(dataDir,specs(i).file);
    if ~isempty(specs(i).file2)
        specs(i).file2 = fullfile(dataDir,specs(i).file2);
    end
end
end

function specs = local_all_specs(dataDir)
specs = struct('name',{},'file',{},'file2',{},'xRows',{},'xCols',{}, ...
    'yRows',{},'yCols',{});
specs(end+1) = local_spec('Jin1','Jin1.xlsx','',2,3,2,2);
specs(end+1) = local_spec('Jin2','Jin2.xlsx','',2,3,2,2);
specs(end+1) = local_spec('homemadeNIR_y230','homemadeNIR.xlsx','',2,2:229,2,230);
specs(end+1) = local_spec('homemadeNIR_y231','homemadeNIR.xlsx','',2,2:229,2,231);
specs(end+1) = local_spec('HunanwetProtein','HunanwetProtein.xlsx','',3,4,3,2);
specs(end+1) = local_spec('Australian_Wheat_y8','Australian_Wheat.csv','',2,9,2,8);
specs(end+1) = local_spec('Australian_Mungbean_y8','Australian_Mungbean.csv','',2,9,2,8);
specs(end+1) = local_spec('HunandryOil','HunandryOil_train.xlsx','HunandryOil_test.xlsx',2,2:142,2,143);
specs(end+1) = local_spec('Cucurbitaceae_Fruits','Cucurbitaceae_Fruits_train.xlsx','Cucurbitaceae_Fruits_test.xlsx',2,2,2,[]);
specs(end+1) = local_spec('Chlorella_Cells','Chlorella Cells per mL - Training Data.csv','Chlorella Cells per mL - Test Data.csv',2,2,2,[]);
specs(end+1) = local_spec('Monoraphidium_Cells','Monoraphidium Cells per mL - Training Data.csv','Monoraphidium Cells per mL - Test Data.csv',2,2,2,[]);
for i = 1:numel(specs)
    specs(i).file = fullfile(dataDir,specs(i).file);
    if ~isempty(specs(i).file2)
        specs(i).file2 = fullfile(dataDir,specs(i).file2);
    end
end
end

function specs = local_existing_specs(specs)
keep = false(numel(specs),1);
for i = 1:numel(specs)
    keep(i) = isfile(specs(i).file) && ...
        (isempty(specs(i).file2) || isfile(specs(i).file2));
end
specs = specs(keep);
end

function s = local_spec(name,file,file2,xRows,xCols,yRows,yCols)
s = struct('name',name,'file',file,'file2',file2,'xRows',xRows, ...
    'xCols',xCols,'yRows',yRows,'yCols',yCols);
end

function [X,y] = local_load_full_dataset(spec)
if isempty(spec.file2)
    I = readmatrix(spec.file);
    xCols = local_cols(spec.xCols,size(I,2));
    yCols = local_cols(spec.yCols,size(I,2));
    X = I(spec.xRows:size(I,1),xCols);
    y = I(spec.yRows:size(I,1),yCols(1));
else
    A = readmatrix(spec.file);
    B = readmatrix(spec.file2);
    yCol = spec.yCols;
    if isempty(yCol), yCol = min(size(A,2),size(B,2)); end
    xCols = intersect(local_cols(spec.xCols,size(A,2)),local_cols(spec.xCols,size(B,2)));
    xCols(xCols == yCol) = [];
    XA = A(spec.xRows:size(A,1),xCols);
    XB = B(spec.xRows:size(B,1),xCols);
    yA = A(spec.yRows:size(A,1),yCol);
    yB = B(spec.yRows:size(B,1),yCol);
    X = [XA;XB];
    y = [yA;yB];
end
end

function cols = local_cols(specCols,nCols)
if isscalar(specCols)
    cols = specCols:nCols;
else
    cols = specCols;
end
cols = cols(cols >= 1 & cols <= nCols);
end

function [X,y] = local_clean_rows(X,y)
y = y(:);
good = all(isfinite(X),2) & isfinite(y);
X = X(good,:);
y = y(good);
end

function [tr,te] = local_random_split(n,ratio)
idx = randperm(n);
nTrain = max(2,min(n-1,floor(ratio*n)));
tr = idx(1:nTrain);
te = idx(nTrain+1:end);
end

function out = local_curvature_exposure_sameQ(plsModel,dcModel,A)
out = [NaN NaN NaN];
if ~isfield(plsModel,'W') || ~isfield(dcModel,'W') || ~isfield(dcModel,'Q')
    return;
end
Ause = min([round(A),size(plsModel.W,2),size(dcModel.W,2),numel(dcModel.Q)]);
if Ause < 1, return; end
ePLS = nan(Ause,1);
eDC = nan(Ause,1);
for a = 1:Ause
    Q = dcModel.Q{a};
    if isempty(Q) || size(Q,1) ~= size(plsModel.W,1), continue; end
    Q = 0.5*(Q+Q');
    wp = plsModel.W(:,a); wd = dcModel.W(:,a);
    wp = wp / max(norm(wp),eps);
    wd = wd / max(norm(wd),eps);
    ePLS(a) = real(wp'*Q*wp);
    eDC(a) = real(wd'*Q*wd);
end
valid = isfinite(ePLS) & isfinite(eDC);
if any(valid)
    out(1) = mean(ePLS(valid));
    out(2) = mean(eDC(valid));
    out(3) = 100*(out(1)-out(2))/max(abs(out(1)),eps);
end
end

function [p,nWins,nLosses,nTies] = local_two_sided_sign_p(d)
d = d(isfinite(d));
nWins = sum(d > 0);
nLosses = sum(d < 0);
nTies = sum(d == 0);
n = nWins + nLosses;
if n == 0
    p = NaN;
    return;
end
k = min(nWins,nLosses);
prob = 0;
for j = 0:k
    prob = prob + nchoosek(n,j)*0.5^n;
end
p = min(1,2*prob);
end

function ci = local_mean_ci(x)
x = x(isfinite(x));
if numel(x) < 2
    ci = [NaN NaN];
    return;
end
ci = mean(x) + [-1 1]*1.96*std(x)/sqrt(numel(x));
end

function s = local_safe_name(s)
s = regexprep(s,'[^A-Za-z0-9_()-]','_');
end
