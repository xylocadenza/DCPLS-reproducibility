function model = radcpls_train(X,y,A,d,k,lambda,cfg)
%RADCPLS_TRAIN Response-aware directional curvature-informed PLS.
% The original dcpls_train.m is preserved. This variant changes only the
% curvature operator by weighting local curvature more strongly where the
% response is locally stable and less strongly where the response varies.
[n,p]=size(X);
A=min([A,p,n-1]);
E=X; f=y(:);
W=zeros(p,A); P=zeros(p,A); q=zeros(A,1); betas=nan(p,A);
Qlist=cell(A,1); exposure=nan(A,1); responseWeights=cell(A,1); actualA=0;
for a=1:A
    c=E'*f;
    if norm(c)<1e-14, break; end
    if lambda==0
        Q=zeros(p,p); wt=c; rw=ones(n,1);
    else
        rw=local_response_stability_weights(E,f,d,k,cfg);
        cfg2=cfg;
        cfg2.curvatureSampleWeights=rw;
        geom=estimate_manifold_curvature(E,d,k,cfg2);
        Q=geom.Q;
        wt=(eye(p)+lambda*Q)\c;
    end
    if norm(wt)<1e-14, break; end
    w=wt/norm(wt);
    t=E*w; den=t'*t;
    if den<1e-14, break; end
    pvec=E'*t/den;
    qa=f'*t/den;
    W(:,a)=w; P(:,a)=pvec; q(a)=qa; Qlist{a}=Q;
    exposure(a)=w'*Q*w; responseWeights{a}=rw; actualA=a;
    Wa=W(:,1:a); Pa=P(:,1:a); qaVec=q(1:a);
    betas(:,a)=Wa*((Pa'*Wa)\qaVec);
    E=E-t*pvec';
    f=f-t*qa;
end
if actualA==0
    model.beta=zeros(p,1); model.betas=zeros(p,1); model.A=0;
else
    model.beta=betas(:,actualA); model.betas=betas(:,1:actualA); model.A=actualA;
end
model.W=W(:,1:actualA); model.P=P(:,1:actualA); model.q=q(1:actualA);
model.Q=Qlist(1:actualA); model.curvatureExposure=exposure(1:actualA);
model.responseCurvatureWeights=responseWeights(1:actualA);
model.d=d; model.k=k; model.lambda=lambda; model.responseAware=true;
end

function rw = local_response_stability_weights(X,y,d,k,cfg)
n=size(X,1);
minK=d*(d+1)/2+d+2;
k=min(max(k,minK),n-1);
y=y(:);
localVar=zeros(n,1);
for i=1:n
    DX=X-X(i,:);
    dist2=sum(DX.^2,2); dist2(i)=inf;
    [~,ord]=sort(dist2,'ascend');
    idx=ord(1:k);
    yi=y(idx);
    localVar(i)=mean((yi-mean(yi)).^2);
end
scale=median(localVar(isfinite(localVar) & localVar>0));
if isempty(scale) || ~isfinite(scale) || scale<=eps
    scale=mean(localVar(isfinite(localVar) & localVar>0));
end
if isempty(scale) || ~isfinite(scale) || scale<=eps
    rw=ones(n,1);
    return;
end
if isfield(cfg,'responseCurvatureEps')
    epsRel=cfg.responseCurvatureEps;
else
    epsRel=0.05;
end
rw=1./(epsRel+localVar/scale);
if isfield(cfg,'responseCurvatureWeightCap')
    cap=cfg.responseCurvatureWeightCap;
else
    cap=10;
end
rw=min(max(rw,1/cap),cap);
m=mean(rw(isfinite(rw)));
if isfinite(m) && m>eps
    rw=rw/m;
else
    rw=ones(n,1);
end
end
