function plot_prediction_scatter(predTable,summaryTable,datasetName,cfg,figDir)
%PLOT_PREDICTION_SCATTER Create ONE 3x3 prediction scatter figure.

methods=cfg.methods;
methods=methods(ismember(methods,unique(predTable.Method,'stable')));

nr=3; nc=3;
vals=[predTable.Reference; predTable.Predicted];
lims=[min(vals),max(vals)];
if diff(lims)<=eps, lims=lims+[-1 1]; end
pad=0.04*diff(lims);
lims=lims+[-pad pad];

f=figure('Visible',cfg.figureVisible,'Position',[60 40 1180 1050]);
tl=tiledlayout(nr,nc,'TileSpacing','compact','Padding','compact');

for m=1:numel(methods)
    nexttile;
    method=methods{m};
    ix=strcmp(predTable.Method,method);
    y=predTable.Reference(ix);
    yh=predTable.Predicted(ix);

    scatter(y,yh,17,'filled');
    hold on;
    plot(lims,lims,'k--','LineWidth',0.9);

    title(method,'Interpreter','none','FontWeight','bold');
    xlabel('Reference');
    ylabel('Predicted');
    grid on; box on; axis square;
    xlim(lims); ylim(lims);

    si=find(strcmp(summaryTable.Method,method),1);
    if ~isempty(si)
       txt = sprintf(['RMSEP = %.4g\n' ...
               '$R_{te}^{2}$ = %.4g'], ...
               summaryTable.RMSEP(si), ...
               summaryTable.R2P(si));

       text(0.04,0.96,txt, ...
           'Units','normalized', ...
           'VerticalAlignment','top', ...
           'BackgroundColor','w', ...
           'Margin',2, ...
           'FontSize',8, ...
           'Interpreter','latex');
    end
end

for m=numel(methods)+1:nr*nc
    nexttile; axis off;
end

title(tl,[datasetName ' prediction scatter plots'], ...
    'Interpreter','none','FontWeight','bold');

if cfg.saveFigures
    if cfg.exportPNG
        exportgraphics(f,fullfile(figDir,'scatter_3x3_ALL_methods.png'),'Resolution',300);
    end
    if cfg.exportFIG
        savefig(f,fullfile(figDir,'scatter_3x3_ALL_methods.fig'));
    end
end
end
