function [Xcal,Xtest,prep] = preprocess_fit_apply(Xcal0,Xtest0,mode)
prep.mode = lower(mode);
prep.mu = mean(Xcal0,1);
switch prep.mode
    case 'center'
        prep.sigma = ones(1,size(Xcal0,2));
    case 'autoscale'
        prep.sigma = std(Xcal0,0,1);
        prep.sigma(prep.sigma < eps) = 1;
    otherwise
        error('Unknown preprocessing mode: %s',mode);
end
Xcal = (Xcal0 - prep.mu) ./ prep.sigma;
Xtest = (Xtest0 - prep.mu) ./ prep.sigma;
end
