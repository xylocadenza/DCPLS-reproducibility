function model = dcpls_fixed_train(X,y,A,d,k,lambda,cfg)
%DCPLS_FIXED_TRAIN DC-PLS using one curvature operator for all components.

[n,p] = size(X);
A = min([A,p,n-1]);
E = X;
f = y(:);
W = zeros(p,A);
P = zeros(p,A);
q = zeros(A,1);
betas = nan(p,A);
exposure = nan(A,1);
actualA = 0;

if lambda == 0
    Q = zeros(p,p);
    geom = [];
else
    geom = estimate_manifold_curvature(X,d,k,cfg);
    Q = geom.Q;
end

for a = 1:A
    c = E'*f;
    if norm(c) < 1e-14, break; end
    wt = (eye(p)+lambda*Q)\c;
    if norm(wt) < 1e-14, break; end
    w = wt/norm(wt);
    t = E*w;
    den = t'*t;
    if den < 1e-14, break; end
    pvec = E'*t/den;
    qa = f'*t/den;
    W(:,a) = w;
    P(:,a) = pvec;
    q(a) = qa;
    exposure(a) = w'*Q*w;
    actualA = a;
    betas(:,a) = W(:,1:a)*((P(:,1:a)'*W(:,1:a))\q(1:a));
    E = E-t*pvec';
    f = f-t*qa;
end

if actualA == 0
    model.beta = zeros(p,1);
    model.betas = zeros(p,1);
    model.A = 0;
else
    model.beta = betas(:,actualA);
    model.betas = betas(:,1:actualA);
    model.A = actualA;
end
model.W = W(:,1:actualA);
model.P = P(:,1:actualA);
model.q = q(1:actualA);
model.Q = repmat({Q},actualA,1);
model.Qfixed = Q;
model.curvatureExposure = exposure(1:actualA);
model.geometry = geom;
model.d = d;
model.k = k;
model.lambda = lambda;
model.curvatureMode = 'fixed';
end
