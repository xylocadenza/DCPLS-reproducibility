%% run_manifest_batch_dcpls.m
% Batch PLS/DC-PLS experiments based on 数据集说明文档.xlsx.
% This script keeps the earlier paper batch untouched and writes a separate
% manifest-based screening result directory.

clc;
close all;

ROOT = fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
addpath('E:\MATLAB\specdataset');
addpath('E:\MATLAB\libPLS_1.95');

if ~exist('dataDir','var'), dataDir = 'E:\MATLAB\specdataset'; end
if ~exist('outRoot','var'), outRoot = fullfile(ROOT,'results','MANIFEST_BATCH_DCPLS'); end
if ~exist(outRoot,'dir'), mkdir(outRoot); end

cfg0 = default_dcpls_config();
cfg0.figureVisible = 'off';
cfg0.saveFigures = false;
cfg0.exportPNG = false;
cfg0.exportFIG = false;
cfg0.innerFolds = 3;
cfg0.AGrid = 1:8;
cfg0.dGrid = 2;
cfg0.kGrid = [15 25];
cfg0.lambdaGrid = [0 0.1 1 10];
if ~exist('methodsToRun','var')
    methodsToRun = {'PLS','DC-PLS'};
end
cfg0.methods = methodsToRun;
cfg0.componentCurveMethods = intersect( ...
    {'PLS','PCR','SPLS','KPLS-RBF','GRPLS','DC-PLS'}, ...
    cfg0.methods,'stable');

% Screening limit: enough to test the manifest consistently without making
% very wide datasets dominate the whole batch. Set to inf for final runs.
if ~exist('maxPredictors','var'), maxPredictors = 300; end
if ~exist('maxSamplesForScreening','var'), maxSamplesForScreening = 900; end
if ~exist('maxOriginalPredictorsForScreening','var')
    maxOriginalPredictorsForScreening = 3500;
end

specs = local_manifest_specs(dataDir);
if exist('selectedNames','var') && ~isempty(selectedNames)
    selectedNames = string(selectedNames);
    specs = specs(ismember(string({specs.name}),selectedNames));
end
summaryRows = {};
failureRows = {};

fprintf('Manifest-based DC-PLS batch\n');
fprintf('Data directory: %s\n',dataDir);
fprintf('Output root:    %s\n',outRoot);
fprintf('Specs:          %d\n',numel(specs));
fprintf('maxPredictors:  %g\n\n',maxPredictors);

for i = 1:numel(specs)
    spec = specs(i);
    fprintf('\n[%d/%d] %s\n',i,numel(specs),spec.name);
    try
        datasetOut = fullfile(outRoot,local_safe_name(spec.name));
        summaryFile = fullfile(datasetOut,'performance_summary.csv');
        if isfile(summaryFile)
            fprintf('  Existing result found; collecting without refitting.\n');
            S = readtable(summaryFile,'TextType','string');
            plsIx = strcmpi(S.Method,'PLS');
            dcIx = strcmpi(S.Method,'DC-PLS') | strcmpi(S.Method,'DCPLS');
            plsRMSEP = NaN; dcRMSEP = NaN; dcR2P = NaN; gain = NaN;
            if any(plsIx), plsRMSEP = S.RMSEP(find(plsIx,1)); end
            if any(dcIx)
                j = find(dcIx,1);
                dcRMSEP = S.RMSEP(j);
                dcR2P = S.R2P(j);
                if ismember('Improvements',S.Properties.VariableNames)
                    gain = S.Improvements(j);
                else
                    gain = 100*(plsRMSEP-dcRMSEP)/plsRMSEP;
                end
            end
            nTrain = NaN; nTest = NaN; p = NaN;
            predFile = fullfile(datasetOut,'test_predictions.csv');
            if isfile(predFile)
                P = readtable(predFile,'TextType','string');
                nTest = nnz(strcmpi(P.Method,'PLS'));
            end
            summaryRows(end+1,:) = {spec.name,nTrain,nTest,p, ...
                plsRMSEP,dcRMSEP,dcR2P,gain,datasetOut}; %#ok<SAGROW>
            continue;
        end

        [Xtrain,ytrain,Xtest,ytest] = local_load_spec(spec);
        if size(Xtrain,1) + size(Xtest,1) > maxSamplesForScreening || ...
                size(Xtrain,2) > maxOriginalPredictorsForScreening
            error('SKIPPED_LARGE: n=%d, p=%d exceeds screening limits.', ...
                size(Xtrain,1) + size(Xtest,1),size(Xtrain,2));
        end
        [Xtrain,Xtest] = local_limit_predictors(Xtrain,Xtest,maxPredictors);
        local_validate_dataset(Xtrain,ytrain,Xtest,ytest,spec.name);

        cfg = cfg0;
        cfg.outputDir = datasetOut;
        if ~exist(cfg.outputDir,'dir'), mkdir(cfg.outputDir); end

        results = run_dcpls_fixed_split_experiment( ...
            Xtrain,ytrain,Xtest,ytest,spec.name,cfg);

        S = results.summary;
        plsIx = strcmpi(S.Method,'PLS');
        dcIx = strcmpi(S.Method,'DC-PLS') | strcmpi(S.Method,'DCPLS');
        plsRMSEP = NaN; dcRMSEP = NaN; dcR2P = NaN; gain = NaN;
        if any(plsIx), plsRMSEP = S.RMSEP(find(plsIx,1)); end
        if any(dcIx)
            j = find(dcIx,1);
            dcRMSEP = S.RMSEP(j);
            dcR2P = S.R2P(j);
            gain = S.Improvements(j);
        end
        summaryRows(end+1,:) = {spec.name,size(Xtrain,1),size(Xtest,1), ...
            size(Xtrain,2),plsRMSEP,dcRMSEP,dcR2P,gain,cfg.outputDir}; %#ok<SAGROW>
    catch ME
        warning('%s failed: %s',spec.name,ME.message);
        failureRows(end+1,:) = {spec.name,ME.message}; %#ok<SAGROW>
    end
end

summaryTable = cell2table(summaryRows,'VariableNames',{ ...
    'Dataset','nTrain','nTest','p','PLS_RMSEP','DCPLS_RMSEP', ...
    'DCPLS_R2P','DCPLS_GainVsPLS_pct','OutputDir'});
if ~isempty(summaryTable)
    summaryTable = sortrows(summaryTable,'DCPLS_GainVsPLS_pct','descend');
end
if isempty(failureRows)
    failureTable = table(strings(0,1),strings(0,1), ...
        'VariableNames',{'Dataset','ErrorMessage'});
else
    failureTable = cell2table(failureRows,'VariableNames',{'Dataset','ErrorMessage'});
end

writetable(summaryTable,fullfile(outRoot,'manifest_summary.csv'));
writetable(failureTable,fullfile(outRoot,'manifest_failures.csv'));

fprintf('\n================ Manifest summary ================\n');
disp(summaryTable);
fprintf('Summary written to: %s\n',fullfile(outRoot,'manifest_summary.csv'));
fprintf('Failures written to: %s\n',fullfile(outRoot,'manifest_failures.csv'));

function specs = local_manifest_specs(dataDir)
specs = struct('name',{},'mode',{},'file',{},'file2',{},'fileY',{}, ...
    'xRows',{},'xCols',{},'yRows',{},'yCols',{},'ratio',{}, ...
    'xVar',{},'yVar',{},'xVar2',{},'yVar2',{});

specs(end+1) = local_matrix(dataDir,'Wulumuqi','Wulumuqi.csv',2,3:local_col('BRT'),2,2,0.8);
specs(end+1) = local_matrix(dataDir,'totalCarbon','totalCarbon.xlsx',3,2:local_col('EHN'),3,1,0.8);
specs(end+1) = local_matrix(dataDir,'SoilNitrigenGLI_fusion','SoilNitrigenGLI_fusion.csv',2,3,2,2,0.8);
specs(end+1) = local_matrix(dataDir,'Soil_fertility_y1552','Soil fertility.xlsx',2,1:1551,2,1552,0.8);
specs(end+1) = local_matrix(dataDir,'Pbcontent','Pbcontent.xlsx',2,3,2,2,0.8);
specs(end+1) = local_matrix(dataDir,'Octane','Octane.xls',2,3,2,2,0.8);
specs(end+1) = local_matrix(dataDir,'nitrogen','nitrogen.csv',1,3,1,1,0.8);
specs(end+1) = local_matrix(dataDir,'NIR_PE','NIR_PE.csv',2,2,2,1,0.8);
specs(end+1) = local_matrix(dataDir,'NIR_PP','NIR_PP.csv',2,2,2,1,0.8);
specs(end+1) = local_matrix(dataDir,'Jin1','Jin1.xlsx',2,3,2,2,0.8);
specs(end+1) = local_matrix(dataDir,'Jin2','Jin2.xlsx',2,3,2,2,0.8);
specs(end+1) = local_matrix(dataDir,'HunandryProtein','HunandryProtein.xlsx',2,3,2,2,0.8);
specs(end+1) = local_matrix(dataDir,'HunanwetProtein','HunanwetProtein.xlsx',2,3,2,2,0.8);
specs(end+1) = local_matrix(dataDir,'homemadeNIR_y230','homemadeNIR.xlsx',2,2:229,2,230,0.8);
specs(end+1) = local_matrix(dataDir,'grapeBrix_y4','grapeBrix.xlsx',2,11:241,2,4,0.8);
specs(end+1) = local_matrix(dataDir,'Faba_bean_Protein','Faba_bean.csv',2,15,2,6,0.8);
specs(end+1) = local_matrix(dataDir,'Cocoa_Bean_samples_y1559','Cocoa Bean samples.xlsx',2,2:1558,2,1559,0.8);
specs(end+1) = local_matrix(dataDir,'Choclate_y1559','Choclate.csv',2,2:1558,2,1559,0.8);
specs(end+1) = local_matrix(dataDir,'beer','beer.csv',1,2,1,1,0.8);
specs(end+1) = local_matrix(dataDir,'Australian_Wheat_y7','Australian_Wheat.csv',2,9,2,7,0.8);
specs(end+1) = local_matrix(dataDir,'Australian_Wheat_y8','Australian_Wheat.csv',2,9,2,8,0.8);
specs(end+1) = local_matrix(dataDir,'Australian_Mungbean_y3','Australian_Mungbean.csv',2,7,2,3,0.8);
specs(end+1) = local_matrix(dataDir,'Australian_Mungbean_y4','Australian_Mungbean.csv',2,7,2,4,0.8);
specs(end+1) = local_matrix(dataDir,'Australian_Mungbean_y5','Australian_Mungbean.csv',2,7,2,5,0.8);
specs(end+1) = local_matrix(dataDir,'Australian_Mungbean_y6','Australian_Mungbean.csv',2,7,2,6,0.8);

specs(end+1) = local_pair_same(dataDir,'HunandryOil','HunandryOil_train.xlsx','HunandryOil_test.xlsx',2,2:142,143);
specs(end+1) = local_pair_same(dataDir,'Cucurbitaceae_Fruits_Water','Cucurbitaceae_Fruits_train.xlsx','Cucurbitaceae_Fruits_test.xlsx',2,4,2);
specs(end+1) = local_pair_same(dataDir,'Cucurbitaceae_Fruits_SSC','Cucurbitaceae_Fruits_train.xlsx','Cucurbitaceae_Fruits_test.xlsx',2,4,3);
specs(end+1) = local_pair_yfile(dataDir,'Wet_chemistry_C','Wet chemistry_Xtr.xlsx','Wet chemistry_Xte.xlsx','Wet chemistry_Y.xlsx',2,2,2,4);
specs(end+1) = local_pair_same(dataDir,'Chlorella_Cells','Chlorella Cells per mL - Training Data.csv','Chlorella Cells per mL - Test Data.csv',2,2,1);
specs(end+1) = local_pair_same(dataDir,'Monoraphidium_Cells','Monoraphidium Cells per mL - Training Data.csv','Monoraphidium Cells per mL - Test Data.csv',2,2,1);

specs(end+1) = local_mat_ks(dataDir,'Wine_v6_y1','Wine_v6.mat','IR_spectra','Pred_values_IR',1,0.8);
specs(end+1) = local_mat_ks(dataDir,'tecator_y123','tecator.mat','tecator(:,1:122)','tecator(:,123)',1,0.8);
specs(end+1) = local_mat_ks(dataDir,'RAMANPorkFat_y1','RAMANPorkFat.mat','X','Y',1,0.8);
specs(end+1) = local_mat_ks(dataDir,'Ramandata_tablets','Ramandata_tablets.MAT','Matrix(:,3:end)','Matrix(:,1)',1,0.8);
specs(end+1) = local_mat_ks(dataDir,'NIRtablet','NIRtablet.mat','spectablet','proptablet',1,0.8);
specs(end+1) = local_mat_ks(dataDir,'NIRsoil_y1','NIRsoil.mat','soil','soilref',1,0.8);
specs(end+1) = local_mat_ks(dataDir,'NIRgrass_y1','NIRgrass.mat','specgrass','propgrass',1,0.8);
% Large sample count; keep it for a separate full run after screening.
% specs(end+1) = local_mat_ks(dataDir,'NIR_sugar','NIR_sugar.mat','X','Brix',1,0.8);
specs(end+1) = local_mat_ks(dataDir,'fred2008_y1','fred2008.mat','fred2008spec','fred2008values',1,0.8);
specs(end+1) = local_mat_ks(dataDir,'fred99a_y1','fred99a.mat','fred99aspec','fred99avalues',1,0.8);
specs(end+1) = local_mat_ks(dataDir,'corn_prop1','corn.mat','m5spec','propvals',1,0.8);

specs(end+1) = local_mat_pair(dataDir,'ShootOut2012MATLAB','ShootOut2012MATLAB.mat','inputCalibration','targetCalibration','inputTest','targetTest',1);
specs(end+1) = local_mat_pair(dataDir,'NITSingleSeed','NITSingleSeed.MAT','Calibration_X','Calibration_Y','Validation_X','Validation_Y',1);
specs(end+1) = local_mat_pair(dataDir,'nir_shootout_2002_set1','nir_shootout_2002.mat','calibrate_1','calibrate_Y','test_1','test_Y',1);
specs(end+1) = local_mat_pair(dataDir,'nir_shootout_2002_set2','nir_shootout_2002.mat','calibrate_2','calibrate_Y','test_2','test_Y',1);
specs(end+1) = local_mat_pair(dataDir,'nir_beer','nir_beer.mat','xcal','ycal','xval','yval',1);
specs(end+1) = local_mat_pair(dataDir,'IDRCShootOut2010Transmit_y1','IDRCShootOut2010Transmit.mat','XcalTrans','YcalTrans','XvalTrans','YvalTrans',1);
% Large sample/matrix datasets; run separately after screening.
% specs(end+1) = local_mat_pair(dataDir,'Dataset1_Shootout2014_y1','Dataset1_Shootout2014.mat','xCal','yCal','xTest','yTest',1);
% specs(end+1) = local_mat_pair(dataDir,'Dataset2_Shootout2014_y1','Dataset2_Shootout2014.mat','xCal','yCal','xTest','yTest',1);

specs = specs(local_files_exist(specs));
end

function s = local_empty(name,mode)
s = struct('name',name,'mode',mode,'file','','file2','','fileY','', ...
    'xRows',[],'xCols',[],'yRows',[],'yCols',[],'ratio',[], ...
    'xVar','','yVar','','xVar2','','yVar2','');
end

function s = local_matrix(dataDir,name,file,xRows,xCols,yRows,yCols,ratio)
s = local_empty(name,'matrix');
s.file = fullfile(dataDir,file); s.xRows = xRows; s.xCols = xCols;
s.yRows = yRows; s.yCols = yCols; s.ratio = ratio;
end

function s = local_pair_same(dataDir,name,trainFile,testFile,rowStart,xCols,yCol)
s = local_empty(name,'pair_same');
s.file = fullfile(dataDir,trainFile); s.file2 = fullfile(dataDir,testFile);
s.xRows = rowStart; s.yRows = rowStart; s.xCols = xCols; s.yCols = yCol;
end

function s = local_pair_yfile(dataDir,name,trainFile,testFile,yFile,xRows,xCols,yRows,yCol)
s = local_empty(name,'pair_yfile');
s.file = fullfile(dataDir,trainFile); s.file2 = fullfile(dataDir,testFile);
s.fileY = fullfile(dataDir,yFile); s.xRows = xRows; s.xCols = xCols;
s.yRows = yRows; s.yCols = yCol;
end

function s = local_mat_ks(dataDir,name,file,xExpr,yExpr,yCol,ratio)
s = local_empty(name,'mat_ks');
s.file = fullfile(dataDir,file); s.xVar = xExpr; s.yVar = yExpr;
s.yCols = yCol; s.ratio = ratio;
end

function s = local_mat_pair(dataDir,name,file,xVar,yVar,xVar2,yVar2,yCol)
s = local_empty(name,'mat_pair');
s.file = fullfile(dataDir,file); s.xVar = xVar; s.yVar = yVar;
s.xVar2 = xVar2; s.yVar2 = yVar2; s.yCols = yCol;
end

function keep = local_files_exist(specs)
keep = false(numel(specs),1);
for ii = 1:numel(specs)
    keep(ii) = isfile(specs(ii).file) && ...
        (isempty(specs(ii).file2) || isfile(specs(ii).file2)) && ...
        (isempty(specs(ii).fileY) || isfile(specs(ii).fileY));
end
end

function [Xtrain,ytrain,Xtest,ytest] = local_load_spec(spec)
switch spec.mode
    case 'matrix'
        M = readmatrix(spec.file);
        [X,y] = local_extract_matrix(M,spec.xRows,spec.xCols,spec.yRows,spec.yCols(1));
        [Xtrain,ytrain,Xtest,ytest] = local_ks_split(X,y,spec.ratio);
    case 'pair_same'
        A = readmatrix(spec.file); B = readmatrix(spec.file2);
        [Xtrain,ytrain] = local_extract_matrix(A,spec.xRows,spec.xCols,spec.yRows,spec.yCols(1));
        [Xtest,ytest] = local_extract_matrix(B,spec.xRows,spec.xCols,spec.yRows,spec.yCols(1));
    case 'pair_yfile'
        [Xtrain,trainNames] = local_read_named_x(spec.file,spec.xRows,spec.xCols);
        [Xtest,testNames] = local_read_named_x(spec.file2,spec.xRows,spec.xCols);
        YT = readtable(spec.fileY,'VariableNamingRule','preserve','TextType','string');
        yNames = string(YT{spec.yRows:end,1});
        yVals = double(YT{spec.yRows:end,spec.yCols(1)});
        ytrain = local_match_response(trainNames,yNames,yVals);
        ytest = local_match_response(testNames,yNames,yVals);
        [Xtrain,ytrain] = local_clean_rows(Xtrain,ytrain);
        [Xtest,ytest] = local_clean_rows(Xtest,ytest);
    case 'mat_ks'
        S = load(spec.file);
        X = local_eval_mat_expr(S,spec.xVar);
        Y = local_eval_mat_expr(S,spec.yVar);
        y = local_y_column(Y,spec.yCols(1));
        [X,y] = local_clean_rows(X,y);
        [Xtrain,ytrain,Xtest,ytest] = local_ks_split(X,y,spec.ratio);
    case 'mat_pair'
        S = load(spec.file);
        Xtrain = local_eval_mat_expr(S,spec.xVar);
        Ytrain = local_eval_mat_expr(S,spec.yVar);
        Xtest = local_eval_mat_expr(S,spec.xVar2);
        Ytest = local_eval_mat_expr(S,spec.yVar2);
        ytrain = local_y_column(Ytrain,spec.yCols(1));
        ytest = local_y_column(Ytest,spec.yCols(1));
        [Xtrain,ytrain] = local_clean_rows(Xtrain,ytrain);
        [Xtest,ytest] = local_clean_rows(Xtest,ytest);
    otherwise
        error('Unknown mode: %s',spec.mode);
end
end

function [X,names] = local_read_named_x(file,rowStart,xCols)
C = readcell(file);
names = string(C(rowStart:end,1));
M = readmatrix(file);
cols = local_cols(xCols,size(M,2));
X = M(rowStart:end,cols);
end

function y = local_match_response(xNames,yNames,yVals)
[tf,loc] = ismember(xNames,yNames);
y = nan(numel(xNames),1);
y(tf) = yVals(loc(tf));
end

function [X,y] = local_extract_matrix(M,xRows,xCols,yRows,yCol)
xCols = local_cols(xCols,size(M,2));
rowsX = xRows:size(M,1);
rowsY = yRows:size(M,1);
X = M(rowsX,xCols);
y = M(rowsY,yCol);
[X,y] = local_clean_rows(X,y);
end

function cols = local_cols(specCols,nCols)
if isempty(specCols), cols = 1:nCols; return; end
if isscalar(specCols)
    cols = specCols:nCols;
else
    cols = specCols;
end
cols = cols(cols >= 1 & cols <= nCols);
end

function y = local_y_column(Y,yCol)
if isvector(Y)
    y = Y(:);
else
    y = Y(:,min(yCol,size(Y,2)));
end
end

function V = local_eval_mat_expr(S,expr)
parts = split(string(expr),'.');
basePart = char(parts(1));
tok = regexp(basePart,'^([A-Za-z]\w*)\((.*)\)$','tokens','once');
if isempty(tok)
    name = basePart; sub = '';
else
    name = tok{1}; sub = tok{2};
end
if ~isfield(S,name), error('MAT variable "%s" not found.',name); end
V = S.(name);
if numel(parts) > 1
    for ii = 2:numel(parts)
        fld = char(parts(ii));
        if ~isstruct(V) || ~isfield(V,fld)
            error('MAT field "%s" not found in expression "%s".',fld,expr);
        end
        V = V.(fld);
    end
end
if ~isempty(sub)
    V = local_apply_subscript(V,sub);
end
end

function V = local_apply_subscript(V,sub)
tok = regexp(sub,'^([^,]+),([^,]+)$','tokens','once');
if isempty(tok), error('Unsupported subscript: %s',sub); end
r = local_subscript_index(strtrim(tok{1}),size(V,1));
c = local_subscript_index(strtrim(tok{2}),size(V,2));
V = V(r,c);
end

function idx = local_subscript_index(txt,n)
if strcmp(txt,':')
    idx = 1:n;
elseif strcmp(txt,'end')
    idx = n;
elseif contains(txt,':')
    p = split(string(txt),':');
    a = local_subscript_index(char(p(1)),n);
    b = local_subscript_index(char(p(2)),n);
    idx = a(1):b(end);
else
    idx = str2double(txt);
end
end

function [X,y] = local_clean_rows(X,y)
X = double(X);
y = double(y(:));
good = all(isfinite(X),2) & isfinite(y);
X = X(good,:);
y = y(good);
end

function [Xtrain,ytrain,Xtest,ytest] = local_ks_split(X,y,ratio)
rank = ks(X);
nTrain = max(2,min(size(X,1)-1,floor(ratio*size(X,1))));
tr = rank(1:nTrain);
te = rank(nTrain+1:end);
Xtrain = X(tr,:); ytrain = y(tr);
Xtest = X(te,:); ytest = y(te);
end

function [Xtrain,Xtest] = local_limit_predictors(Xtrain,Xtest,maxPredictors)
if isfinite(maxPredictors) && size(Xtrain,2) > maxPredictors
    idx = unique(round(linspace(1,size(Xtrain,2),maxPredictors)));
    Xtrain = Xtrain(:,idx);
    Xtest = Xtest(:,idx);
end
end

function local_validate_dataset(Xtrain,ytrain,Xtest,ytest,name)
if size(Xtrain,1) < 20 || size(Xtest,1) < 5
    error('%s has too few samples after cleaning.',name);
end
if size(Xtrain,2) < 2
    error('%s has too few predictor variables.',name);
end
if std(ytrain) <= eps || std(ytest) <= eps
    error('%s response is constant after cleaning.',name);
end
end

function n = local_col(label)
label = upper(char(label));
n = 0;
for ii = 1:numel(label)
    n = n*26 + (double(label(ii))-double('A')+1);
end
end

function s = local_safe_name(s)
s = regexprep(s,'[^A-Za-z0-9_()-]','_');
end
