function plot_rmse_component_curves_fixed(curveTable,datasetName,cfg,figDir,metric)
%PLOT_RMSE_COMPONENT_CURVES_FIXED Single fixed-split component curves.

methods=cfg.componentCurveMethods;
f=figure('Visible',cfg.figureVisible,'Position',[100 100 850 600]);
hold on;

for i=1:numel(methods)
    method=methods{i};
    ix=strcmp(curveTable.Method,method);
    if ~any(ix), continue; end

    T=curveTable(ix,:);
    [~,ord]=sort(T.Component);
    T=T(ord,:);

    if strcmpi(metric,'RMSEP')
        yy=T.RMSEP;
    else
        yy=T.RMSEC;
    end

    plot(T.Component,yy,'-o','LineWidth',1.2,'MarkerSize',4, ...
        'DisplayName',method);
end

xlabel('Number of latent components');
ylabel(metric);
title([datasetName ': ' metric ' vs latent components'],'Interpreter','none');
grid on; box on;
legend('Location','best','Interpreter','none');

if cfg.saveFigures
    if cfg.exportPNG
        exportgraphics(f,fullfile(figDir,[metric '_vs_components.png']),'Resolution',300);
    end
    if cfg.exportFIG
        savefig(f,fullfile(figDir,[metric '_vs_components.fig']));
    end
end
end
