function [Phi2,pairs] = quadratic_features(u)
[k,d]=size(u);
m2=d*(d+1)/2;
Phi2=zeros(k,m2); pairs=zeros(m2,2); q=0;
for a=1:d
    q=q+1;
    Phi2(:,q)=0.5*u(:,a).^2;
    pairs(q,:)=[a a];
end
for a=1:d-1
    for b=a+1:d
        q=q+1;
        Phi2(:,q)=u(:,a).*u(:,b);
        pairs(q,:)=[a b];
    end
end
end
