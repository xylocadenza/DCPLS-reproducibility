%% run_runtime_analysis_dcpls.m
% Lightweight runtime comparison for PLS and DC-PLS on representative data.

clc;
close all;

ROOT = fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
addpath('E:\MATLAB\specdataset');
addpath('E:\MATLAB\libPLS_1.95');

if ~exist('dataDir','var'), dataDir = 'E:\MATLAB\specdataset'; end
if ~exist('fixedRoot','var'), fixedRoot = fullfile(ROOT,'results','SPEC_DATASETS'); end
if ~exist('outRoot','var'), outRoot = fullfile(ROOT,'results','RUNTIME_ANALYSIS'); end
if ~exist('nRepeats','var'), nRepeats = 5; end
if ~exist('maxPredictors','var'), maxPredictors = 300; end
if ~exist(outRoot,'dir'), mkdir(outRoot); end

cfg = default_dcpls_config();
cfg.figureVisible = 'off';
cfg.saveFigures = false;
cfg.exportPNG = false;
cfg.exportFIG = false;

specs = local_representative_specs(dataDir);
rows = {};

for si = 1:numel(specs)
    spec = specs(si);
    fprintf('\n=== Runtime: %s ===\n',spec.name);
    [Xtrain,ytrain,Xtest,ytest] = local_load_dataset(spec); %#ok<ASGLU>
    [Xtrain,Xtest] = local_limit_predictors(Xtrain,Xtest,maxPredictors);
    [Xtr,~] = preprocess_fit_apply(Xtrain,Xtest,cfg.preprocess);
    ytr = ytrain(:) - mean(ytrain);
    Amax = min(10,min(size(Xtr,2),size(Xtr,1)-1));

    hp = readtable(fullfile(fixedRoot,local_safe_name(spec.name),'selected_hyperparameters.csv'), ...
        'TextType','string');
    tunePLS = local_tune_from_table(hp,'PLS');
    tuneDC = local_tune_from_table(hp,'DC-PLS');

    tPLS = nan(nRepeats,1);
    tDC = nan(nRepeats,1);
    for r = 1:nRepeats
        f = @() fit_method_with_curve(Xtr,ytr,'PLS',tunePLS,cfg,Amax);
        tPLS(r) = timeit(f);
        g = @() fit_method_with_curve(Xtr,ytr,'DC-PLS',tuneDC,cfg,Amax);
        tDC(r) = timeit(g);
        fprintf('repeat %d: PLS %.4fs, DC-PLS %.4fs\n',r,tPLS(r),tDC(r));
    end

    rows(end+1,:) = {spec.name,size(Xtrain,1),size(Xtest,1),size(Xtrain,2), ...
        tunePLS.A,tuneDC.A,tuneDC.d,tuneDC.k,tuneDC.lambda, ...
        mean(tPLS),std(tPLS),mean(tDC),std(tDC),mean(tDC)/max(mean(tPLS),eps)}; %#ok<SAGROW>
end

runtimeTable = cell2table(rows,'VariableNames',{ ...
    'Dataset','nTrain','nTest','p','PLS_A','DCPLS_A','DCPLS_d','DCPLS_k', ...
    'DCPLS_lambda','PLS_time_mean_s','PLS_time_sd_s', ...
    'DCPLS_time_mean_s','DCPLS_time_sd_s','Runtime_ratio'});
writetable(runtimeTable,fullfile(outRoot,'runtime_summary.csv'));
disp(runtimeTable);

function tune = local_tune_from_table(T,method)
ix = find(strcmpi(T.Method,method) | (strcmpi(method,'DC-PLS') & strcmpi(T.Method,'DCPLS')),1);
if isempty(ix), error('Missing hyperparameters for %s.',method); end
names = {'A','d','k','lambda','ridgeLambda','localK','graphK','graphAlpha', ...
    'rbfGamma','krrLambda','sparseTau','kplsGamma','RMSECV'};
for i = 1:numel(names)
    if ismember(names{i},T.Properties.VariableNames)
        tune.(names{i}) = T.(names{i})(ix);
    else
        tune.(names{i}) = NaN;
    end
end
end

function specs = local_representative_specs(dataDir)
specs = struct('name',{},'mode',{},'file',{},'file2',{},'xRows',{}, ...
    'xCols',{},'yRows',{},'yCols',{},'ratio',{});
specs(end+1) = local_spec_matrix('HunanwetProtein','HunanwetProtein.xlsx',3,4,3,2,0.8);
specs(end+1) = local_spec_pair('Cucurbitaceae_Fruits','Cucurbitaceae_Fruits_train.xlsx','Cucurbitaceae_Fruits_test.xlsx',2,2,[]);
specs(end+1) = local_spec_matrix('Australian_Wheat_y8','Australian_Wheat.csv',2,9,2,8,0.8);
specs(end+1) = local_spec_matrix('Jin1','Jin1.xlsx',2,3,2,2,0.8);
specs(end+1) = local_spec_pair('HunandryOil','HunandryOil_train.xlsx','HunandryOil_test.xlsx',2,2:142,143);
for i = 1:numel(specs)
    specs(i).file = fullfile(dataDir,specs(i).file);
    if ~isempty(specs(i).file2), specs(i).file2 = fullfile(dataDir,specs(i).file2); end
end
end

function s = local_spec_matrix(name,file,xRowStart,xCols,yRowStart,yCols,ratio)
s = struct('name',name,'mode','matrix','file',file,'file2','', ...
    'xRows',xRowStart,'xCols',xCols,'yRows',yRowStart,'yCols',yCols,'ratio',ratio);
end

function s = local_spec_pair(name,trainFile,testFile,rowStart,xCols,yCol)
s = struct('name',name,'mode','pair','file',trainFile,'file2',testFile, ...
    'xRows',rowStart,'xCols',xCols,'yRows',rowStart,'yCols',yCol,'ratio',[]);
end

function [Xtrain,ytrain,Xtest,ytest] = local_load_dataset(spec)
switch spec.mode
    case 'matrix'
        I = readmatrix(spec.file);
        xCols = local_cols(spec.xCols,size(I,2));
        yCols = local_cols(spec.yCols,size(I,2));
        X = I(spec.xRows:size(I,1),xCols);
        y = I(spec.yRows:size(I,1),yCols(1));
        [X,y] = local_clean_rows(X,y);
        [Xtrain,ytrain,Xtest,ytest] = local_ks_split(X,y,spec.ratio);
    case 'pair'
        A = readmatrix(spec.file);
        B = readmatrix(spec.file2);
        yCol = spec.yCols;
        if isempty(yCol), yCol = min(size(A,2),size(B,2)); end
        xCols = intersect(local_cols(spec.xCols,size(A,2)),local_cols(spec.xCols,size(B,2)));
        xCols(xCols == yCol) = [];
        Xtrain = A(spec.xRows:size(A,1),xCols);
        ytrain = A(spec.xRows:size(A,1),yCol);
        Xtest = B(spec.xRows:size(B,1),xCols);
        ytest = B(spec.xRows:size(B,1),yCol);
        [Xtrain,ytrain] = local_clean_rows(Xtrain,ytrain);
        [Xtest,ytest] = local_clean_rows(Xtest,ytest);
end
end

function [Xtrain,Xtest] = local_limit_predictors(Xtrain,Xtest,maxPredictors)
if isfinite(maxPredictors) && size(Xtrain,2) > maxPredictors
    idx = unique(round(linspace(1,size(Xtrain,2),maxPredictors)));
    Xtrain = Xtrain(:,idx);
    Xtest = Xtest(:,idx);
end
end

function cols = local_cols(specCols,nCols)
if isscalar(specCols), cols = specCols:nCols; else, cols = specCols; end
cols = cols(cols >= 1 & cols <= nCols);
end

function [X,y] = local_clean_rows(X,y)
y = y(:);
good = all(isfinite(X),2) & isfinite(y);
X = X(good,:);
y = y(good);
end

function [Xtrain,ytrain,Xtest,ytest] = local_ks_split(X,y,ratio)
rank = ks(X);
nTrain = floor(ratio*size(X,1));
tr = rank(1:nTrain);
te = rank(nTrain+1:end);
Xtrain = X(tr,:);
ytrain = y(tr);
Xtest = X(te,:);
ytest = y(te);
end

function s = local_safe_name(s)
s = regexprep(s,'[^A-Za-z0-9_()-]','_');
end
