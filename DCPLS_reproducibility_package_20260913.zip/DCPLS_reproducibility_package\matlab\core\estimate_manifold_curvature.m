function geom = estimate_manifold_curvature(X,d,k,cfg)
[n,p]=size(X);
d=min([d,p,max(1,n-2)]);
minK=d*(d+1)/2+d+2;
k=min(max(k,minK),n-1);
if isfield(cfg,'curvatureSampleWeights') && numel(cfg.curvatureSampleWeights)==n
    sampleWeights=cfg.curvatureSampleWeights(:);
    sampleWeights(~isfinite(sampleWeights) | sampleWeights<0)=0;
else
    sampleWeights=ones(n,1);
end
weightSum=sum(sampleWeights);
if weightSum<=eps
    sampleWeights=ones(n,1);
    weightSum=n;
end
Q=zeros(p,p);
II_Fro2=nan(n,1); Hnorm2=nan(n,1); GaussianK=nan(n,1);
LocalRadius=nan(n,1); EffectiveN=nan(n,1);
TangentResidual=nan(n,1); QuadraticResidual=nan(n,1); QuadraticCondition=nan(n,1);
for i=1:n
    DXall=X-X(i,:);
    dist2=sum(DXall.^2,2); dist2(i)=inf;
    [sd,ord]=sort(dist2,'ascend');
    idx=ord(1:k); DX=DXall(idx,:); rr=sqrt(sd(1:k));
    h=max(rr); if ~isfinite(h)||h<=eps, h=1; end
    LocalRadius(i)=h;
    z=min(rr/h,1);
    switch lower(cfg.kernel)
        case 'tricube'
            wloc=(1-z.^3).^3;
        case 'gaussian'
            wloc=exp(-0.5*(rr/max(h/2,eps)).^2);
        otherwise
            error('Unknown kernel: %s',cfg.kernel);
    end
    wloc=max(wloc,cfg.minWeight);
    EffectiveN(i)=(sum(wloc)^2)/sum(wloc.^2);
    Xw=DX.*sqrt(wloc);
    [~,~,V]=svd(Xw,'econ');
    di=min(d,size(V,2)); U=V(:,1:di);
    u=DX*U; R=DX-u*U';
    TangentResidual(i)=sqrt(sum(wloc.*sum(R.^2,2))/sum(wloc));
    [Phi2,pairs]=quadratic_features(u);
    Phi=[ones(k,1),u,Phi2];
    M=Phi'*(Phi.*wloc);
    m2=size(Phi2,2); quadIdx=(2+di):(1+di+m2);
    quadScale=mean(diag(M(quadIdx,quadIdx)));
    if ~isfinite(quadScale)||quadScale<=eps, quadScale=1; end
    rridge=cfg.geomRidge*quadScale;
    Gamma=zeros(size(M));
    Gamma(2:1+di,2:1+di)=cfg.geomLinearRidgeFactor*rridge*eye(di);
    Gamma(quadIdx,quadIdx)=rridge*eye(m2);
    % Solve the weighted ridge problem from the augmented least-squares
    % system rather than the normal equations.  This avoids squaring the
    % condition number of Phi and suppresses the near-singular-matrix
    % warnings that can occur for highly collinear local spectral patches.
    Aw=Phi.*sqrt(wloc);
    Bw=R.*sqrt(wloc);
    gammaDiag=diag(Gamma);

    % Column scaling improves conditioning while preserving the original
    % coefficient parameterization.  The transformed ridge penalty is
    % adjusted accordingly.
    colScale=sqrt(sum(Aw.^2,1));
    colScale(colScale<sqrt(eps))=1;
    Z=bsxfun(@rdivide,Aw,colScale);
    regScaled=sqrt(max(gammaDiag,0))./colScale(:);
    Aaug=[Z; diag(regScaled)];
    Baug=[Bw; zeros(size(Phi,2),p)];

    [Us,Ss,Vs]=svd(Aaug,'econ');
    sing=diag(Ss);
    if isempty(sing) || sing(1)<=0
        Theta=zeros(size(Phi,2),p);
        QuadraticCondition(i)=inf;
    else
        tol=max(size(Aaug))*eps(sing(1));
        keep=sing>tol;
        if ~any(keep)
            Theta=zeros(size(Phi,2),p);
            QuadraticCondition(i)=inf;
        else
            Theta=Vs(:,keep)*(bsxfun(@rdivide,Us(:,keep)'*Baug,sing(keep)));
            QuadraticCondition(i)=sing(1)/sing(find(keep,1,'last'));
        end
    end
    C=bsxfun(@rdivide,Theta,colScale(:));
    Rfit=R-Phi*C;
    QuadraticResidual(i)=sqrt(sum(wloc.*sum(Rfit.^2,2))/sum(wloc));
    C2=C(quadIdx,:);
    for qj=1:m2
        v=C2(qj,:)'; v=v-U*(U'*v); C2(qj,:)=v';
    end
    H=zeros(p,di,di);
    for qj=1:m2
        a=pairs(qj,1); b=pairs(qj,2); v=C2(qj,:)';
        H(:,a,b)=v; H(:,b,a)=v;
    end
    G=zeros(di,di);
    for b=1:di
        for c=1:di
            s=0;
            for a=1:di
                s=s+H(:,a,b)'*H(:,a,c);
            end
            G(b,c)=s;
        end
    end
    G=(G+G')/2;
    [VG,DG]=eig(G); ev=diag(DG); ev(ev<0)=0;
    G=VG*diag(ev)*VG'; G=(G+G')/2;
    Q=Q+sampleWeights(i)*(U*G*U');
    II_Fro2(i)=sum(H(:).^2);
    Hmean=zeros(p,1);
    for a=1:di, Hmean=Hmean+H(:,a,a); end
    Hmean=Hmean/di; Hnorm2(i)=Hmean'*Hmean;
    if di==2
        GaussianK(i)=H(:,1,1)'*H(:,2,2)-H(:,1,2)'*H(:,1,2);
    end
end
Q=Q/weightSum; Q=(Q+Q')/2;
if cfg.qNormalize
    s=trace(Q)/p;
    if isfinite(s)&&s>1e-14, Q=Q/s; end
end
geom.Q=Q; geom.II_Fro2=II_Fro2; geom.Hnorm2=Hnorm2; geom.GaussianK=GaussianK;
geom.LocalRadius=LocalRadius; geom.EffectiveN=EffectiveN;
geom.TangentResidual=TangentResidual; geom.QuadraticResidual=QuadraticResidual;
geom.QuadraticCondition=QuadraticCondition;
end
