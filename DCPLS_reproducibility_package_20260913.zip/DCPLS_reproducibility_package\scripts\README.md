# Scripts

Scripts for reproducing the reported analyses.

Suggested order:

1. Prepare raw datasets locally according to `metadata/`.
2. Add the repository paths in MATLAB:

```matlab
addpath(genpath('matlab'));
addpath(genpath('scripts'));
```

3. Run synthetic validation:

```matlab
run_synthetic_geometry_validation
```

4. Run 47-task screening or selected-task analyses after data preparation:

```matlab
run_manifest_batch_dcpls
```

5. Run additional analyses:

```matlab
run_fixed_vs_reestimated_curvature_ablation
run_nit_repeated_validation
run_runtime_analysis_dcpls
run_parameter_sensitivity_dcpls
```

