function model = pcr_train(X,y,A)
[n,p]=size(X);
A=min([A,p,n-1]);
[~,~,V]=svd(X,'econ');
A=min(A,size(V,2));
betas=nan(p,A);
for a=1:A
    Va=V(:,1:a);
    T=X*Va;
    betas(:,a)=Va*(T\y);
end
model.betas=betas;
model.beta=betas(:,A);
model.A=A;
end
