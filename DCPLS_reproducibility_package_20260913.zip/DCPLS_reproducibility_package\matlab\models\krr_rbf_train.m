function model = krr_rbf_train(X,y,gamma,lambda)
%KRR_RBF_TRAIN Toolbox-free Gaussian-kernel ridge regression.
D2 = sqdist_rows(X,X);
K = exp(-gamma*D2);
n = size(K,1);
alpha = (K + lambda*eye(n))\y(:);
model.type = 'KRR-RBF';
model.Xtrain = X;
model.alpha = alpha;
model.gamma = gamma;
model.lambda = lambda;
end

function D2 = sqdist_rows(A,B)
aa=sum(A.^2,2); bb=sum(B.^2,2)';
D2=max(aa+bb-2*(A*B'),0);
end
