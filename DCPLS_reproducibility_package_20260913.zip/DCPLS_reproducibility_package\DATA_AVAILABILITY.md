# Data Availability

This repository does **not** redistribute third-party spectral datasets unless redistribution is explicitly allowed by the original data provider.

## What Is Included

The repository includes:

- MATLAB implementation of DC-PLS and baseline methods
- scripts used to run the reported experiments
- selected hyperparameter files
- prediction-output CSV files
- 47-task screening records
- Supplementary Table S1 and S2
- metadata templates for dataset source, citation, and download tracking

## What Is Not Included

The repository does not include raw third-party spectra or response files when their redistribution terms are unclear or restrictive.

Users should obtain raw data from the original sources and place them in a local data directory. The expected dataset organization should be documented in `metadata/datasets_metadata_template.csv` or a completed metadata table supplied with the final release.

## Required Dataset Metadata

For each dataset/task, the following should be recorded:

- dataset/task name
- original dataset name
- source URL or DOI
- recommended citation
- download/access date
- license or redistribution condition
- predictor variable name or file
- response variable name or file
- response unit
- calibration/test split rule
- prepared calibration indices
- prepared test indices
- preprocessing notes

## Split Reproducibility

For datasets with fixed external prediction sets, the original calibration/test files should be documented.

For datasets split by Kennard-Stone or random holdout, deterministic split routines and indices should be provided in `splits/` or regenerated with the scripts in this repository.

## Permanent Repository or DOI

Before final publication, replace this placeholder note with the actual permanent repository URL or DOI.

