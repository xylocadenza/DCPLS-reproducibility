function plot_rmse_component_curves(T,datasetName,cfg,figDir,metric)
f=figure('Visible',cfg.figureVisible); hold on;
methods=unique(T.Method,'stable');
for m=1:numel(methods)
    method=methods{m}; ix=strcmp(T.Method,method); x=T.Component(ix);
    switch upper(metric)
        case 'RMSEP'
            mu=T.RMSEP_Mean(ix); lo=T.RMSEP_CI_Low(ix); hi=T.RMSEP_CI_High(ix);
        case 'RMSEC'
            mu=T.RMSEC_Mean(ix); lo=T.RMSEC_CI_Low(ix); hi=T.RMSEC_CI_High(ix);
        otherwise
            error('metric must be RMSEP or RMSEC.');
    end
    good=isfinite(x)&isfinite(mu)&isfinite(lo)&isfinite(hi);
    x=x(good); mu=mu(good); lo=lo(good); hi=hi(good); if isempty(x), continue; end
    h=plot(x,mu,'-o','LineWidth',1.5,'DisplayName',method); c=get(h,'Color');
    fill([x;flipud(x)],[lo;flipud(hi)],c,'FaceAlpha',0.12,'EdgeColor','none','HandleVisibility','off');
    uistack(h,'top');
end
xlabel('Number of latent components'); ylabel(metric);
title(sprintf('%s: %s vs latent components',datasetName,metric),'Interpreter','none');
grid on; box on; legend('Location','best');
name=sprintf('%s_vs_components',lower(metric));
if cfg.saveFigures
    if cfg.exportPNG, exportgraphics(f,fullfile(figDir,[name '.png']),'Resolution',300); end
    if cfg.exportFIG, savefig(f,fullfile(figDir,[name '.fig'])); end
end
end
