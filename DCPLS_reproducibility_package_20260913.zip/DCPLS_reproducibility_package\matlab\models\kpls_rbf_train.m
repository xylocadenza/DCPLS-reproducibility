function model = kpls_rbf_train(X,y,A,gamma)
%KPLS_RBF_TRAIN RBF-kernel PLS1 baseline.
% A centered Gram matrix is treated as the predictor representation and
% conventional PLS1 is performed in that kernel space.

K=rbf_kernel(X,X,gamma);
colMean=mean(K,1);
grandMean=mean(K(:));
Kc=K-colMean-mean(K,2)+grandMean;

pls=pls_nipals_train(Kc,y,A);

model.type='KPLS-RBF';
model.Xtrain=X;
model.gamma=gamma;
model.trainKernelColMean=colMean;
model.trainKernelGrandMean=grandMean;
model.beta=pls.beta;       % coefficients in centered kernel-coordinate space
model.betas=pls.betas;
model.A=pls.A;
model.W=pls.W;
model.P=pls.P;
model.q=pls.q;
end

function K=rbf_kernel(A,B,gamma)
aa=sum(A.^2,2);
bb=sum(B.^2,2)';
D2=max(aa+bb-2*(A*B'),0);
K=exp(-gamma*D2);
end
