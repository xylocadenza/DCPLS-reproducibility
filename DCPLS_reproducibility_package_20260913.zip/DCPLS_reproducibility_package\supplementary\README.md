# Supplementary Files

This folder contains supplementary tables referenced in the manuscript.

- `Supplementary_Table_S1_47task_screening.csv`
- `Supplementary_Table_S2_selected_dcpls_hyperparameters.csv`

S1 should include task names, PLS and DC-PLS RMSEP values, relative RMSEP change, improve/tie/worsen label, selected DC-PLS hyperparameters, RMSECV, and output directories.

