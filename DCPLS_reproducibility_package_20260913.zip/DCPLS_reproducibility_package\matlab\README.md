# MATLAB Code

Main folders:

- `core/`: directional SFF-energy estimation
- `models/`: DC-PLS and baseline regression models
- `utils/`: preprocessing and split helpers
- `plotting/`: figure utilities

Entry points:

- `default_dcpls_config.m`
- `selftest_package.m`

Run `selftest_package` first to check that the local code is on the MATLAB path.

