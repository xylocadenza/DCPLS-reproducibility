# Metadata

This folder is for dataset provenance and source metadata.

Complete `datasets_metadata_template.csv` before public release. Do not invent missing DOI, URL, license, or citation information. If a dataset cannot be redistributed, mark `RedistributionAllowed` as `No` and provide source/access instructions instead.

