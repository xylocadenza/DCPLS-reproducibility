# Directional Curvature-Informed PLS

This repository contains the MATLAB code and reproducibility materials for the manuscript:

**Directional Curvature-Informed Partial Least Squares for High-Dimensional Spectral Calibration**

The proposed DC-PLS method extends conventional PLS by incorporating a directional second-fundamental-form energy operator into latent-variable extraction. The repository is organized to support review, reproduction of reported tables, and future reuse of the code.

## Repository Layout

```text
matlab/          Core DC-PLS and baseline model code
scripts/         Scripts used to regenerate experiments and tables
metadata/        Dataset-source metadata templates and notes
splits/          Split-generation notes and deterministic split routines
results/         Lightweight result CSV files and prediction outputs
supplementary/   Supplementary Table S1/S2 used in the manuscript
docs/            Additional notes for reviewers/users
```

## Software Environment

The experiments were developed with:

- MATLAB R2024a
- No required third-party MATLAB toolbox for the included in-house baseline implementations
- Optional: libPLS may be used for comparison with external PLS routines, but the package includes a local NIPALS PLS implementation

The scripts assume that third-party spectral datasets are downloaded separately and arranged according to the metadata and data availability notes.

## Quick Start

From MATLAB, run:

```matlab
root = pwd;
addpath(genpath(fullfile(root, 'matlab')));
addpath(genpath(fullfile(root, 'scripts')));
selftest_package
```

To reproduce the main screening workflow after preparing the datasets:

```matlab
run('scripts/run_manifest_batch_dcpls.m')
```

To regenerate synthetic geometry validation:

```matlab
run('scripts/run_synthetic_geometry_validation.m')
```

To regenerate the fixed versus re-estimated operator ablation:

```matlab
run('scripts/run_fixed_vs_reestimated_curvature_ablation.m')
```

## Data Availability

Raw spectral datasets are not redistributed here unless their original license explicitly permits redistribution. See `DATA_AVAILABILITY.md` and `metadata/` for source-tracking templates, prepared-index expectations, and reproduction notes.

## Results Included

This package includes lightweight result files:

- 47-task screening summary
- selected hyperparameters
- prediction outputs
- synthetic-geometry summaries
- fixed-vs-re-estimated operator ablation
- supplementary tables used in the manuscript

Large raw data files and generated MATLAB `.mat` result objects are intentionally excluded from the GitHub-ready package.

## Citation

If you use this code, please cite the associated manuscript after publication. A DOI or stable publication link should be added here before final public release.

