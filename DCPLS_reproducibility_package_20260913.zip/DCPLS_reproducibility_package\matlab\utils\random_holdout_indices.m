function [idxCal,idxTest] = random_holdout_indices(n,testFraction)
nTest = max(1,round(n*testFraction));
perm = randperm(n);
idxTest = sort(perm(1:nTest));
idxCal = sort(perm(nTest+1:end));
end
