function model = localpls_train(X,y,A,k)
%LOCALPLS_TRAIN Query-adaptive local PLS model.
model.type='LocalPLS';
model.Xtrain=X;
model.ytrain=y(:);
model.A=A;
model.k=min(k,size(X,1));
end
