%% run_synthetic_geometry_validation.m
% Truth-based validation of the directional second-fundamental-form energy.

clc;
close all;

ROOT = fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outRoot = fullfile(ROOT,'results','SYNTHETIC_GEOMETRY');
if ~exist(outRoot,'dir'), mkdir(outRoot); end

cfg = default_dcpls_config();
cfg.qNormalize = false;
cfg.geomRidge = 1e-6;
cfg.geomLinearRidgeFactor = 0.1;
cfg.kernel = 'tricube';

sampleSizes = [150 300 600];
noiseLevels = [0 0.002 0.01];
nRep = 10;
ambientDim = 20;
baseSeed = 20260912;
manifolds = {'plane','cylinder','sphere','paraboloid'};
rows = cell(0,9);

for mi = 1:numel(manifolds)
    for ni = 1:numel(sampleSizes)
        for si = 1:numel(noiseLevels)
            for rep = 1:nRep
                rng(baseSeed + 10000*mi + 1000*ni + 100*si + rep,'twister');
                n = sampleSizes(ni);
                sigma = noiseLevels(si);
                [X,Qtrue] = make_manifold(manifolds{mi},n,ambientDim,sigma);
                k = min(n-1,max(20,round(2.5*sqrt(n))));
                geom = estimate_manifold_curvature(X,2,k,cfg);
                Qhat = 0.5*(geom.Q+geom.Q');
                relError = norm(Qhat-Qtrue,'fro')/max(norm(Qtrue,'fro'),eps);
                if norm(Qtrue,'fro') <= 1e-12
                    relError = norm(Qhat,'fro');
                end
                [Vt,Dt] = eig(Qtrue,'vector');
                [Vh,Dh] = eig(Qhat,'vector');
                [~,it] = sort(Dt,'descend');
                [~,ih] = sort(Dh,'descend');
                rankTrue = sum(Dt > max(Dt)*1e-8);
                if rankTrue > 0
                    Ut = Vt(:,it(1:rankTrue));
                    Uh = Vh(:,ih(1:rankTrue));
                    subspaceError = norm(Ut*Ut'-Uh*Uh','fro')/sqrt(2*rankTrue);
                    eigRatio = sum(max(Dh,0))/max(sum(max(Dt,0)),eps);
                else
                    subspaceError = NaN;
                    eigRatio = NaN;
                end
                rows(end+1,:) = {manifolds{mi},n,sigma,rep,k,relError, ...
                    subspaceError,eigRatio,trace(Qhat)}; %#ok<SAGROW>
            end
        end
    end
end

T = cell2table(rows,'VariableNames',{'Manifold','N','NoiseSD','Repeat','k', ...
    'RelativeOperatorError','SubspaceError','EigenvalueSumRatio','EstimatedTrace'});
writetable(T,fullfile(outRoot,'synthetic_geometry_runs.csv'));

S = groupsummary(T,{'Manifold','N','NoiseSD'},'mean', ...
    {'RelativeOperatorError','SubspaceError','EigenvalueSumRatio','EstimatedTrace'});
writetable(S,fullfile(outRoot,'synthetic_geometry_summary.csv'));
disp(S);

function [X,Qtrue] = make_manifold(kind,n,p,sigma)
switch kind
    case 'plane'
        u = 2*rand(n,2)-1;
        Z = [u zeros(n,1)];
        G = zeros(2);
    case 'cylinder'
        theta = 2*pi*rand(n,1);
        z = 2*rand(n,1)-1;
        Z = [cos(theta) sin(theta) z];
        % Uniform sampling gives equal average tangent orientation in x-y.
        Q3 = diag([0.5 0.5 0]);
        G = [];
    case 'sphere'
        v = randn(n,3); v = v./vecnorm(v,2,2);
        Z = v;
        % Unit sphere: G=I in every tangent plane, E[UU']=2I/3.
        Q3 = (2/3)*eye(3);
        G = [];
    case 'paraboloid'
        u = 0.6*(2*rand(n,2)-1);
        a = 0.35; b = 0.15;
        Z = [u a*u(:,1).^2+b*u(:,2).^2];
        % Small-domain reference at the vertex, sufficient for trend checking.
        G = diag([(2*a)^2 (2*b)^2]);
    otherwise
        error('Unknown manifold.');
end

[R,~] = qr(randn(p,3),0);
X = Z*R';
if sigma > 0, X = X + sigma*randn(size(X)); end
if exist('Q3','var')
    Qtrue = R*Q3*R';
else
    U3 = [1 0;0 1;0 0];
    Qtrue = R*U3*G*U3'*R';
end
Qtrue = 0.5*(Qtrue+Qtrue');
end
