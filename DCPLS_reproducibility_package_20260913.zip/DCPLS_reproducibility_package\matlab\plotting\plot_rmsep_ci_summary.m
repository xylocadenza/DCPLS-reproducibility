function plot_rmsep_ci_summary(T,datasetName,cfg,figDir)
f=figure('Visible',cfg.figureVisible);
x=1:height(T); mu=T.RMSEP_Mean; elo=mu-T.RMSEP_CI_Low; ehi=T.RMSEP_CI_High-mu;
errorbar(x,mu,elo,ehi,'o','LineWidth',1.4,'MarkerSize',7);
set(gca,'XTick',x,'XTickLabel',T.Method); xtickangle(25);
ylabel('RMSEP'); title(sprintf('%s: mean RMSEP with %.0f%% CI',datasetName,100*cfg.confLevel),'Interpreter','none');
grid on; box on;
if cfg.saveFigures
    if cfg.exportPNG, exportgraphics(f,fullfile(figDir,'RMSEP_confidence_intervals.png'),'Resolution',300); end
    if cfg.exportFIG, savefig(f,fullfile(figDir,'RMSEP_confidence_intervals.fig')); end
end
end
